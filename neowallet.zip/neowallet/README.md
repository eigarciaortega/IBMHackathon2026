# NeoWallet — P2P Payments MVP

Billetera digital con dos microservicios independientes (**Accounts Service** y
**Processor Service**), Python + FastAPI + PostgreSQL, orquestados con Docker
Compose. Implementa el patrón **Saga** con compensación para que el dinero
nunca se pierda en una transferencia fallida.

## Arquitectura

```
Cliente (curl/Postman)
        │
        ├── Accounts Service  (:3000) ── accounts-db  (:5432)
        │     GET  /accounts/{id}
        │     POST /api/recharge
        │     POST /accounts/update-balance   (interno)
        │
        └── Processor Service (:3001) ── processor-db (:5433)
              POST /api/transfer        ──► llama a accounts-service por HTTP
              GET  /api/transactions/{id}
```

## Cómo correrlo

```bash
docker compose up --build
```

Espera ~10-15s a que ambas bases de datos pasen el healthcheck. Luego:

- Accounts Service: http://localhost:3000
- Processor Service: http://localhost:3001
- Docs interactivas (Swagger): http://localhost:3000/docs y http://localhost:3001/docs

Datos semilla ya cargados (`init.sql`):

| id | nombre              | balance |
|----|---------------------|---------|
| 1  | Usuario A (Rico)    | 1000.00 |
| 2  | Usuario B (Pobre)   | 50.00   |
| 3  | Usuario C (Nuevo)   | 0.00    |

## Probar con curl

```bash
# Consultar saldo
curl http://localhost:3000/accounts/1

# Recargar saldo
curl -X POST http://localhost:3000/api/recharge \
  -H "Content-Type: application/json" \
  -d '{"user_id": 3, "amount": 100.50}'

# Transferencia P2P exitosa
curl -X POST http://localhost:3001/api/transfer \
  -H "Content-Type: application/json" \
  -d '{"sender_id": 1, "receiver_id": 2, "amount": 100}'

# Fondos insuficientes (Usuario B solo tiene 50)
curl -X POST http://localhost:3001/api/transfer \
  -H "Content-Type: application/json" \
  -d '{"sender_id": 2, "receiver_id": 1, "amount": 500}'

# Auto-transferencia (rechazada)
curl -X POST http://localhost:3001/api/transfer \
  -H "Content-Type: application/json" \
  -d '{"sender_id": 1, "receiver_id": 1, "amount": 10}'

# Historial de transacciones (bonus)
curl http://localhost:3001/api/transactions/1
```

## Correr los tests (sin Docker, usan SQLite en memoria)

```bash
cd accounts-service
pip install -r requirements.txt
pytest -v

cd ../processor-service
pip install -r requirements.txt
pytest -v
```

Los tests del `processor-service` simulan (mockean) las llamadas HTTP al
`accounts-service`, así que no necesitas levantar Docker para correrlos.
El test más importante es `test_transfer_credit_failure_triggers_rollback`:
simula que el débito al sender funciona pero el crédito al receiver falla,
y verifica que el sistema **revierte automáticamente el débito** (estado
`ROLLED_BACK`) — esto demuestra que nunca se pierde dinero.

## Patrón Saga implementado en `/api/transfer`

1. Valida `sender != receiver`, monto > 0, y que ambos usuarios existan.
2. Crea la transacción en estado `PENDING`.
3. Debita al sender → estado `DEBITED`.
4. Acredita al receiver:
   - Si funciona → estado `COMPLETED`. ✅
   - Si falla → **compensación**: se le acredita de vuelta al sender el
     mismo monto que se le debitó, y la transacción queda en `ROLLED_BACK`.
     Si incluso la compensación falla, queda en `FAILED` con un
     `error_message` detallado para reconciliación manual.

## Estructura del proyecto

```
neowallet/
├── docker-compose.yml
├── accounts-service/
│   ├── app/
│   │   ├── main.py        # endpoints
│   │   ├── crud.py        # acceso a datos (con SELECT ... FOR UPDATE)
│   │   ├── models.py      # modelo SQLAlchemy User
│   │   ├── schemas.py     # esquemas Pydantic
│   │   └── database.py
│   ├── tests/
│   ├── init.sql           # seed data
│   ├── Dockerfile
│   └── requirements.txt
└── processor-service/
    ├── app/
    │   ├── main.py            # endpoint /api/transfer con patrón Saga
    │   ├── accounts_client.py # cliente HTTP hacia accounts-service
    │   ├── crud.py
    │   ├── models.py          # modelo SQLAlchemy Transaction
    │   ├── schemas.py
    │   └── database.py
    ├── tests/
    ├── init.sql
    ├── Dockerfile
    └── requirements.txt
```

## Decisiones de diseño rápidas

- **`SELECT ... FOR UPDATE`** en `crud.get_user_for_update` para evitar
  race conditions si dos operaciones tocan el mismo saldo a la vez.
- **Códigos de error explícitos** (`insufficient_funds`,
  `self_transfer_not_allowed`, `invalid_amount`, `user_not_found`) en vez
  de mensajes genéricos, para que el cliente pueda manejar cada caso.
- **Sin frontend ni auth** — está fuera de alcance según el documento de
  requerimientos; todo se prueba con curl/Postman/Swagger.
- **Historial de transacciones** (`GET /api/transactions/{id}`) incluido
  como bonus, con tipo `sent`/`received` y el `counterparty_id`.

## Qué falta si quieres seguir sumando puntos bonus

- Job de reconciliación que revise transacciones en `FAILED` y reintente
  la compensación periódicamente.
- Logs estructurados en JSON (actualmente usa el logging default de
  uvicorn).
- Paginación en el historial de transacciones.
