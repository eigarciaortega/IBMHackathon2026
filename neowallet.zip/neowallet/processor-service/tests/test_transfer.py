from unittest.mock import patch

from app import accounts_client, models


FAKE_USERS = {
    1: {"id": 1, "name": "A", "email": "a@x.com", "balance": "1000.00"},
    2: {"id": 2, "name": "B", "email": "b@x.com", "balance": "50.00"},
}


def fake_get_account(user_id):
    if user_id not in FAKE_USERS:
        raise accounts_client.AccountsServiceError(404, "user_not_found", f"User {user_id} not found")
    return FAKE_USERS[user_id]


def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200


def test_transfer_success(client):
    with patch("app.accounts_client.get_account", side_effect=fake_get_account), patch(
        "app.accounts_client.update_balance", return_value={"ok": True}
    ) as mock_update:
        resp = client.post("/api/transfer", json={"sender_id": 1, "receiver_id": 2, "amount": 100})

    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "COMPLETED"
    assert data["sender_id"] == 1
    assert data["receiver_id"] == 2
    assert mock_update.call_count == 2  # debit + credit


def test_transfer_self_transfer_rejected(client):
    resp = client.post("/api/transfer", json={"sender_id": 1, "receiver_id": 1, "amount": 10})
    assert resp.status_code == 400
    assert resp.json()["detail"]["error"] == "self_transfer_not_allowed"


def test_transfer_negative_amount_rejected(client):
    resp = client.post("/api/transfer", json={"sender_id": 1, "receiver_id": 2, "amount": -5})
    assert resp.status_code == 400
    assert resp.json()["detail"]["error"] == "invalid_amount"


def test_transfer_zero_amount_rejected(client):
    resp = client.post("/api/transfer", json={"sender_id": 1, "receiver_id": 2, "amount": 0})
    assert resp.status_code == 400
    assert resp.json()["detail"]["error"] == "invalid_amount"


def test_transfer_sender_not_found(client):
    with patch("app.accounts_client.get_account", side_effect=fake_get_account):
        resp = client.post("/api/transfer", json={"sender_id": 999, "receiver_id": 2, "amount": 10})
    assert resp.status_code == 404
    assert resp.json()["detail"]["error"] == "user_not_found"


def test_transfer_receiver_not_found(client):
    with patch("app.accounts_client.get_account", side_effect=fake_get_account):
        resp = client.post("/api/transfer", json={"sender_id": 1, "receiver_id": 999, "amount": 10})
    assert resp.status_code == 404
    assert resp.json()["detail"]["error"] == "user_not_found"


def test_transfer_insufficient_funds(client):
    def fake_update_balance(user_id, amount, operation):
        if operation == "debit":
            raise accounts_client.AccountsServiceError(400, "insufficient_funds", "not enough money")
        return {"ok": True}

    with patch("app.accounts_client.get_account", side_effect=fake_get_account), patch(
        "app.accounts_client.update_balance", side_effect=fake_update_balance
    ):
        resp = client.post("/api/transfer", json={"sender_id": 2, "receiver_id": 1, "amount": 100})

    assert resp.status_code == 400
    assert resp.json()["detail"]["error"] == "insufficient_funds"


def test_transfer_credit_failure_triggers_rollback(client, db_session):
    """
    Caso crítico (CU-005): si el débito tuvo éxito pero el crédito falla,
    el sistema debe revertir el débito (compensación) para que no se pierda dinero.
    """
    call_log = []

    def fake_update_balance(user_id, amount, operation):
        call_log.append((user_id, operation))
        # El segundo llamado (crédito al receiver) falla
        if operation == "credit" and len(call_log) == 2:
            raise accounts_client.AccountsServiceError(503, "service_unavailable", "receiver service down")
        return {"ok": True}

    with patch("app.accounts_client.get_account", side_effect=fake_get_account), patch(
        "app.accounts_client.update_balance", side_effect=fake_update_balance
    ):
        resp = client.post("/api/transfer", json={"sender_id": 1, "receiver_id": 2, "amount": 100})

    assert resp.status_code == 502
    # 1) debit sender  2) credit receiver (falla)  3) compensación: credit de vuelta al sender
    assert call_log == [(1, "debit"), (2, "credit"), (1, "credit")]

    tx = db_session.query(models.Transaction).first()
    assert tx.status == "ROLLED_BACK"


def test_transactions_history_empty(client):
    resp = client.get("/api/transactions/1")
    assert resp.status_code == 200
    assert resp.json()["transactions"] == []


def test_transactions_history_after_transfer(client):
    with patch("app.accounts_client.get_account", side_effect=fake_get_account), patch(
        "app.accounts_client.update_balance", return_value={"ok": True}
    ):
        client.post("/api/transfer", json={"sender_id": 1, "receiver_id": 2, "amount": 100})

    resp_sender = client.get("/api/transactions/1")
    assert resp_sender.status_code == 200
    txs = resp_sender.json()["transactions"]
    assert len(txs) == 1
    assert txs[0]["type"] == "sent"
    assert txs[0]["counterparty_id"] == 2

    resp_receiver = client.get("/api/transactions/2")
    txs2 = resp_receiver.json()["transactions"]
    assert txs2[0]["type"] == "received"
    assert txs2[0]["counterparty_id"] == 1
