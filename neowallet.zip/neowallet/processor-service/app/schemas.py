from decimal import Decimal
from datetime import datetime
from typing import List

from pydantic import BaseModel


class TransferRequest(BaseModel):
    sender_id: int
    receiver_id: int
    amount: Decimal


class TransferResponse(BaseModel):
    transaction_id: int
    sender_id: int
    receiver_id: int
    amount: Decimal
    status: str


class TransactionOut(BaseModel):
    id: int
    counterparty_id: int
    type: str  # "sent" | "received"
    amount: Decimal
    status: str
    created_at: datetime

    class Config:
        from_attributes = True


class TransactionHistoryResponse(BaseModel):
    user_id: int
    transactions: List[TransactionOut]
