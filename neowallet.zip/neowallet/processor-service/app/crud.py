from typing import Optional
from sqlalchemy.orm import Session
from . import models


def create_transaction(db: Session, sender_id: int, receiver_id: int, amount, status="PENDING"):
    tx = models.Transaction(
        sender_id=sender_id, receiver_id=receiver_id, amount=amount, status=status
    )
    db.add(tx)
    db.commit()
    db.refresh(tx)
    return tx


def update_transaction_status(
    db: Session, tx: models.Transaction, status: str, error_message: Optional[str] = None
):
    tx.status = status
    if error_message is not None:
        tx.error_message = error_message
    db.commit()
    db.refresh(tx)
    return tx


def get_transactions_for_user(db: Session, user_id: int):
    return (
        db.query(models.Transaction)
        .filter(
            (models.Transaction.sender_id == user_id)
            | (models.Transaction.receiver_id == user_id)
        )
        .order_by(models.Transaction.created_at.desc())
        .all()
    )
