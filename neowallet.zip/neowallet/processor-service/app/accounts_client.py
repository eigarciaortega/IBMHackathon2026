import os
from typing import Optional

import httpx

ACCOUNTS_SERVICE_URL = os.getenv("ACCOUNTS_SERVICE_URL", "http://localhost:3000")

TIMEOUT = httpx.Timeout(5.0)


class AccountsServiceError(Exception):
    """Envuelve cualquier error devuelto por accounts-service (o de red)."""

    def __init__(self, status_code: int, error: str, message: str):
        self.status_code = status_code
        self.error = error
        self.message = message
        super().__init__(message)


def _request(method: str, path: str, json: Optional[dict] = None) -> dict:
    url = f"{ACCOUNTS_SERVICE_URL}{path}"
    try:
        with httpx.Client(timeout=TIMEOUT) as client:
            resp = client.request(method, url, json=json)
    except httpx.RequestError as exc:
        raise AccountsServiceError(
            503, "service_unavailable", f"Could not reach accounts-service: {exc}"
        )

    if resp.status_code >= 400:
        try:
            detail = resp.json().get("detail", {})
            error = detail.get("error", "unknown_error")
            message = detail.get("message", resp.text)
        except Exception:
            error = "unknown_error"
            message = resp.text
        raise AccountsServiceError(resp.status_code, error, message)

    return resp.json()


def get_account(user_id: int) -> dict:
    return _request("GET", f"/accounts/{user_id}")


def update_balance(user_id: int, amount, operation: str) -> dict:
    payload = {"user_id": user_id, "amount": float(amount), "operation": operation}
    return _request("POST", "/accounts/update-balance", json=payload)
