from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session

from . import models, schemas, crud, accounts_client
from .database import engine, get_db

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="NeoWallet - Processor Service", version="1.0.0")


@app.get("/health")
def health():
    return {"status": "ok", "service": "processor-service"}


@app.post("/api/transfer", response_model=schemas.TransferResponse)
def transfer(payload: schemas.TransferRequest, db: Session = Depends(get_db)):
    # --- Validaciones de negocio (antes de tocar dinero) ---
    if payload.sender_id == payload.receiver_id:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "self_transfer_not_allowed",
                "message": "sender and receiver must be different",
            },
        )
    if payload.amount <= 0:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_amount", "message": "amount must be greater than zero"},
        )
    if round(payload.amount, 2) != payload.amount:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "invalid_amount",
                "message": "amount must have at most 2 decimal places",
            },
        )

    # --- Verificar que ambos usuarios existan ---
    try:
        accounts_client.get_account(payload.sender_id)
    except accounts_client.AccountsServiceError as exc:
        if exc.status_code == 404:
            raise HTTPException(
                status_code=404,
                detail={
                    "error": "user_not_found",
                    "message": f"sender {payload.sender_id} not found",
                },
            )
        raise HTTPException(status_code=exc.status_code, detail={"error": exc.error, "message": exc.message})

    try:
        accounts_client.get_account(payload.receiver_id)
    except accounts_client.AccountsServiceError as exc:
        if exc.status_code == 404:
            raise HTTPException(
                status_code=404,
                detail={
                    "error": "user_not_found",
                    "message": f"receiver {payload.receiver_id} not found",
                },
            )
        raise HTTPException(status_code=exc.status_code, detail={"error": exc.error, "message": exc.message})

    # --- 1. Crear transacción PENDING ---
    tx = crud.create_transaction(
        db, payload.sender_id, payload.receiver_id, payload.amount, status="PENDING"
    )

    # --- 2. Debitar al sender ---
    try:
        accounts_client.update_balance(payload.sender_id, payload.amount, "debit")
    except accounts_client.AccountsServiceError as exc:
        crud.update_transaction_status(db, tx, "FAILED", error_message=exc.message)
        if exc.error == "insufficient_funds":
            raise HTTPException(
                status_code=400, detail={"error": "insufficient_funds", "message": exc.message}
            )
        raise HTTPException(status_code=exc.status_code, detail={"error": exc.error, "message": exc.message})

    crud.update_transaction_status(db, tx, "DEBITED")

    # --- 3. Acreditar al receiver ---
    try:
        accounts_client.update_balance(payload.receiver_id, payload.amount, "credit")
    except accounts_client.AccountsServiceError as exc:
        # Compensación (Saga): revertir el débito para que no se pierda dinero
        try:
            accounts_client.update_balance(payload.sender_id, payload.amount, "credit")
            crud.update_transaction_status(
                db,
                tx,
                "ROLLED_BACK",
                error_message=f"Credit to receiver failed ({exc.message}); debit reverted",
            )
        except accounts_client.AccountsServiceError as compensation_exc:
            # Peor caso: la compensación también falló. Requiere reconciliación manual.
            crud.update_transaction_status(
                db,
                tx,
                "FAILED",
                error_message=(
                    f"Credit failed ({exc.message}) AND compensation failed "
                    f"({compensation_exc.message}). Needs manual reconciliation."
                ),
            )
        raise HTTPException(
            status_code=502,
            detail={
                "error": "transfer_failed",
                "message": "Transfer could not be completed; any debit was reverted.",
            },
        )

    tx = crud.update_transaction_status(db, tx, "COMPLETED")

    return schemas.TransferResponse(
        transaction_id=tx.id,
        sender_id=tx.sender_id,
        receiver_id=tx.receiver_id,
        amount=tx.amount,
        status=tx.status,
    )


@app.get("/api/transactions/{user_id}", response_model=schemas.TransactionHistoryResponse)
def get_transactions(user_id: int, db: Session = Depends(get_db)):
    txs = crud.get_transactions_for_user(db, user_id)
    result = []
    for tx in txs:
        if tx.sender_id == user_id:
            counterparty = tx.receiver_id
            tx_type = "sent"
        else:
            counterparty = tx.sender_id
            tx_type = "received"
        result.append(
            schemas.TransactionOut(
                id=tx.id,
                counterparty_id=counterparty,
                type=tx_type,
                amount=tx.amount,
                status=tx.status,
                created_at=tx.created_at,
            )
        )
    return schemas.TransactionHistoryResponse(user_id=user_id, transactions=result)
