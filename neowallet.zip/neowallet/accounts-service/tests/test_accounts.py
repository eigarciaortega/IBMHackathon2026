from decimal import Decimal


def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_get_account_success(client, seed_users):
    user = seed_users[0]
    resp = client.get(f"/accounts/{user.id}")
    assert resp.status_code == 200
    data = resp.json()
    assert data["id"] == user.id
    assert Decimal(data["balance"]) == Decimal("1000.00")


def test_get_account_not_found(client, seed_users):
    resp = client.get("/accounts/9999")
    assert resp.status_code == 404
    assert resp.json()["detail"]["error"] == "user_not_found"


def test_get_account_invalid_id(client):
    resp = client.get("/accounts/-1")
    assert resp.status_code == 400
    assert resp.json()["detail"]["error"] == "invalid_user_id"


def test_recharge_success(client, seed_users):
    user = seed_users[2]  # balance 0
    resp = client.post("/api/recharge", json={"user_id": user.id, "amount": 100.50})
    assert resp.status_code == 200
    data = resp.json()
    assert Decimal(data["new_balance"]) == Decimal("100.50")
    assert Decimal(data["previous_balance"]) == Decimal("0.00")


def test_recharge_negative_amount_rejected(client, seed_users):
    user = seed_users[0]
    resp = client.post("/api/recharge", json={"user_id": user.id, "amount": -10})
    assert resp.status_code == 400
    assert resp.json()["detail"]["error"] == "invalid_amount"


def test_recharge_zero_amount_rejected(client, seed_users):
    user = seed_users[0]
    resp = client.post("/api/recharge", json={"user_id": user.id, "amount": 0})
    assert resp.status_code == 400
    assert resp.json()["detail"]["error"] == "invalid_amount"


def test_recharge_user_not_found(client):
    resp = client.post("/api/recharge", json={"user_id": 99999, "amount": 10})
    assert resp.status_code == 404
    assert resp.json()["detail"]["error"] == "user_not_found"


def test_update_balance_debit_success(client, seed_users):
    user = seed_users[0]  # balance 1000
    resp = client.post(
        "/accounts/update-balance",
        json={"user_id": user.id, "amount": 100, "operation": "debit"},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert Decimal(data["new_balance"]) == Decimal("900.00")


def test_update_balance_debit_insufficient_funds(client, seed_users):
    user = seed_users[1]  # balance 50
    resp = client.post(
        "/accounts/update-balance",
        json={"user_id": user.id, "amount": 100, "operation": "debit"},
    )
    assert resp.status_code == 400
    assert resp.json()["detail"]["error"] == "insufficient_funds"


def test_update_balance_credit_success(client, seed_users):
    user = seed_users[1]  # balance 50
    resp = client.post(
        "/accounts/update-balance",
        json={"user_id": user.id, "amount": 50, "operation": "credit"},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert Decimal(data["new_balance"]) == Decimal("100.00")


def test_update_balance_user_not_found(client):
    resp = client.post(
        "/accounts/update-balance",
        json={"user_id": 99999, "amount": 10, "operation": "credit"},
    )
    assert resp.status_code == 404
