from decimal import Decimal
from datetime import datetime
from typing import Optional, Literal

from pydantic import BaseModel, Field


class UserOut(BaseModel):
    id: int
    name: str
    email: str
    balance: Decimal
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class RechargeRequest(BaseModel):
    user_id: int
    amount: Decimal
    payment_method: Optional[str] = "simulated"


class RechargeResponse(BaseModel):
    user_id: int
    previous_balance: Decimal
    new_balance: Decimal
    amount: Decimal


class UpdateBalanceRequest(BaseModel):
    user_id: int
    amount: Decimal = Field(..., gt=0)
    operation: Literal["debit", "credit"]


class UpdateBalanceResponse(BaseModel):
    user_id: int
    previous_balance: Decimal
    new_balance: Decimal
    operation: str
