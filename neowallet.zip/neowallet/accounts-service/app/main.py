from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session

from . import models, schemas, crud
from .database import engine, get_db

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="NeoWallet - Accounts Service", version="1.0.0")


@app.get("/health")
def health():
    return {"status": "ok", "service": "accounts-service"}


@app.get("/accounts/{user_id}", response_model=schemas.UserOut)
def get_account(user_id: int, db: Session = Depends(get_db)):
    if user_id <= 0:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_user_id", "message": "user_id must be a positive integer"},
        )

    user = crud.get_user(db, user_id)
    if user is None:
        raise HTTPException(
            status_code=404,
            detail={"error": "user_not_found", "message": f"User {user_id} not found"},
        )

    return user


@app.post("/api/recharge", response_model=schemas.RechargeResponse)
def recharge(payload: schemas.RechargeRequest, db: Session = Depends(get_db)):
    if payload.amount <= 0:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_amount", "message": "amount must be greater than zero"},
        )
    if round(payload.amount, 2) != payload.amount:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_amount", "message": "amount must have at most 2 decimal places"},
        )

    user = crud.get_user(db, payload.user_id)
    if user is None:
        raise HTTPException(
            status_code=404,
            detail={"error": "user_not_found", "message": f"User {payload.user_id} not found"},
        )

    previous_balance, new_balance = crud.recharge_balance(db, payload.user_id, payload.amount)

    return schemas.RechargeResponse(
        user_id=payload.user_id,
        previous_balance=previous_balance,
        new_balance=new_balance,
        amount=payload.amount,
    )


@app.post("/accounts/update-balance", response_model=schemas.UpdateBalanceResponse)
def update_balance(payload: schemas.UpdateBalanceRequest, db: Session = Depends(get_db)):
    """Endpoint interno usado por el Processor Service para debitar/acreditar saldo."""
    user = crud.get_user(db, payload.user_id)
    if user is None:
        raise HTTPException(
            status_code=404,
            detail={"error": "user_not_found", "message": f"User {payload.user_id} not found"},
        )

    try:
        result = crud.update_balance(db, payload.user_id, payload.amount, payload.operation)
    except crud.InsufficientFundsError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "insufficient_funds", "message": str(exc)},
        )

    if result is None:
        raise HTTPException(
            status_code=404,
            detail={"error": "user_not_found", "message": f"User {payload.user_id} not found"},
        )

    previous_balance, new_balance = result

    return schemas.UpdateBalanceResponse(
        user_id=payload.user_id,
        previous_balance=previous_balance,
        new_balance=new_balance,
        operation=payload.operation,
    )
