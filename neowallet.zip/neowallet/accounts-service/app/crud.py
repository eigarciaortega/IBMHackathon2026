from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import models


class InsufficientFundsError(Exception):
    """Se lanza cuando un débito excede el saldo disponible."""


def get_user(db: Session, user_id: int):
    return db.get(models.User, user_id)


def get_user_for_update(db: Session, user_id: int):
    """SELECT ... FOR UPDATE: bloquea la fila para evitar condiciones de carrera
    cuando dos operaciones intentan modificar el mismo saldo al mismo tiempo."""
    stmt = select(models.User).where(models.User.id == user_id).with_for_update()
    return db.execute(stmt).scalar_one_or_none()


def recharge_balance(db: Session, user_id: int, amount: Decimal):
    user = get_user_for_update(db, user_id)
    if user is None:
        return None
    previous_balance = user.balance
    user.balance = user.balance + amount
    db.commit()
    db.refresh(user)
    return previous_balance, user.balance


def update_balance(db: Session, user_id: int, amount: Decimal, operation: str):
    """
    operation: 'debit' o 'credit'.
    Retorna (saldo_anterior, saldo_nuevo) o None si el usuario no existe.
    Lanza InsufficientFundsError si un débito excede el saldo disponible.
    """
    user = get_user_for_update(db, user_id)
    if user is None:
        return None

    previous_balance = user.balance

    if operation == "debit":
        if user.balance < amount:
            raise InsufficientFundsError(
                f"User {user_id} has insufficient funds: "
                f"balance={user.balance}, requested={amount}"
            )
        user.balance = user.balance - amount
    elif operation == "credit":
        user.balance = user.balance + amount
    else:
        raise ValueError(f"Invalid operation: {operation}")

    db.commit()
    db.refresh(user)
    return previous_balance, user.balance
