Feature: Motor de Reservas de OfficeSpace
  Como colaborador de Corporativo Alpha
  Quiero reservar espacios sin conflictos de horario
  Para evitar duplicidad de reservas y desorganización en la oficina

  Background:
    Given el sistema tiene un espacio "Sala Creativa" con capacidad 8
    And existe una reserva CONFIRMED en "Sala Creativa" de "09:00" a "10:00" hoy

  Scenario: Rechazar el "abrazo" de horarios
    When intento reservar "Sala Creativa" de "08:30" a "10:30" hoy
    Then la respuesta debe ser 409
    And la reserva NO debe crearse

  Scenario: Rechazar solapamiento parcial al inicio
    When intento reservar "Sala Creativa" de "08:30" a "09:30" hoy
    Then la respuesta debe ser 409

  Scenario: Rechazar solapamiento parcial al final
    When intento reservar "Sala Creativa" de "09:30" a "10:30" hoy
    Then la respuesta debe ser 409

  Scenario: Permitir reservas consecutivas (límite exclusivo)
    When intento reservar "Sala Creativa" de "10:00" a "11:00" hoy
    Then la respuesta debe ser 201
    And la reserva debe quedar CONFIRMED

  Scenario: Rechazar capacidad excedida
    When intento reservar "Sala Creativa" de "14:00" a "15:00" hoy con 10 asistentes
    Then la respuesta debe ser 400
    And el mensaje debe mencionar "excede la capacidad"

  Scenario: Rechazar hora de fin menor a hora de inicio
    When intento reservar "Sala Creativa" de "11:00" a "09:00" hoy
    Then la respuesta debe ser 400

  Scenario: Rechazar fecha en el pasado
    When intento reservar "Sala Creativa" de "09:00" a "10:00" ayer
    Then la respuesta debe ser 400

  Scenario: Rechazar creación de reserva sin autenticación
    Given no tengo un token JWT válido
    When intento reservar "Sala Creativa" de "16:00" a "17:00" hoy
    Then la respuesta debe ser 401

  Scenario: Un colaborador no puede gestionar espacios
    Given inicié sesión como colaborador
    When intento crear un nuevo espacio
    Then la respuesta debe ser 403

  Scenario: Solo el dueño de la reserva o un admin pueden cancelarla
    Given Carlos creó una reserva futura
    And inicié sesión como Ana (otra colaboradora)
    When intento cancelar la reserva de Carlos
    Then la respuesta debe ser 403
