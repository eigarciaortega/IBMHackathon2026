# Reporte de Bugs — "The Office Auditor"

Bugs encontrados en el `Buggy Controller` de referencia (sección 7.2 del brief) y
cómo los corrige nuestra implementación real (`booking-service` / `catalog-service`).

| ID Bug | Título del Defecto | Severidad | Pasos para Reproducir | Resultado Esperado | Resultado Obtenido (Buggy Controller) | Estado en nuestra implementación |
|---|---|---|---|---|---|---|
| 001 | Permite reserva con hora de fin menor a inicio | S2 (Alta) | `POST /bookings` con `start: 10:00, end: 08:00` | Error de validación (400) | La reserva se crea (201) | ✅ Corregido — `isEndAfterStart()` devuelve 400 |
| 002 | Solapamiento de horarios no detectado | S1 (Crítica) | Reservar 09:00-10:00, luego 09:30-10:30 | El sistema debe rechazar (409) | El sistema lo permite (201) | ✅ Corregido — `isOverlapping()` con regla `newStart < existingEnd AND existingStart < newEnd` |
| 003 | Status code incorrecto en conflicto | S2 (Alta) | Crear reserva duplicada exacta | Debe retornar 409 Conflict | Retorna 200 OK con mensaje de error | ✅ Corregido — devuelve 409 real |
| 004 | No valida capacidad vs asistentes | S1 (Crítica) | Reservar sala de 8 para 10 personas | Debe rechazar (400) | Permite la reserva (201) | ✅ Corregido — `isCapacityValid()` |
| 005 | Falta autenticación en endpoints | S1 (Crítica) | `POST /bookings` sin header Authorization | Debe retornar 401 | Permite crear reserva | ✅ Corregido — middleware `verifyToken` en todas las rutas mutables |
| 006 | Cualquiera puede eliminar reservas | S1 (Crítica) | `DELETE /bookings/1` sin autenticación | Debe retornar 401 | Elimina la reserva (200) | ✅ Corregido — `verifyToken` + verificación de dueño/admin (403 si no aplica) |
| 007 | Filtro de capacidad ignorado en búsqueda | S2 (Alta) | `GET /spaces?minCapacity=10` con solo salas de 8 | No debe listar la sala de 8 | La devuelve igual | ✅ Corregido — filtro `capacity >= @minCapacity` aplicado en SQL |
| 008 | No valida permisos por rol en CRUD de espacios | S1 (Crítica) | Colaborador hace `POST /api/spaces` | Debe rechazar (403) | (No existía en el Buggy Controller original; lo añadimos como caso propio) | ✅ Cubierto — middleware `requireRole('ADMINISTRADOR')` |

## Notas para QA Lead

- Los bugs 005, 006 y 008 son los de mayor impacto de seguridad: sin autenticación,
  cualquier persona con la URL del API puede crear, leer o borrar reservas de otros.
- El bug 002 es el corazón del reto: una mala condición de solapamiento (`start === start`
  en vez de un rango real) es el error más común y más fácil de pasar por alto en code review.
  Se cubre explícitamente con pruebas unitarias (`tests/bookingValidators.test.js`) y con la
  colección de Postman (carpeta "3. Booking - Lógica Crítica").
- Recomendación de proceso: ningún PR que tocara `bookingValidators.js` debería mergearse
  sin que `npm test` pase en `booking-service`.
