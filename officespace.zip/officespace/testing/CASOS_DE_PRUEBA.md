# Casos de Prueba Manuales - OfficeSpace

Formato: Precondiciones · Pasos · Resultado Esperado

---

### CP-01 — Login exitoso como Administrador
**Precondiciones:** Sistema levantado, usuario `admin@corporativoalpha.com` existe.
**Pasos:**
1. Ir a `Login.html`.
2. Ingresar `admin@corporativoalpha.com` / `Admin123`.
3. Click en "Iniciar Sesión".
**Resultado esperado:** Login 200, token guardado, redirección a `Administrador.html`.

---

### CP-02 — Login con credenciales inválidas
**Precondiciones:** Sistema levantado.
**Pasos:**
1. Ir a `Login.html`.
2. Ingresar `admin@corporativoalpha.com` / `clave_incorrecta`.
3. Click en "Iniciar Sesión".
**Resultado esperado:** Respuesta 401, mensaje "Credenciales inválidas" visible, sin redirección.

---

### CP-03 — Colaborador no puede acceder al panel de Admin
**Precondiciones:** Login exitoso como `carlos.mendez@corporativoalpha.com`.
**Pasos:**
1. Navegar manualmente a `Administrador.html` con el token de colaborador.
**Resultado esperado:** El frontend detecta `role !== 'ADMINISTRADOR'` y redirige a `Colaborador.html`. La API también debe rechazar `POST/PUT/DELETE /api/spaces` con 403 si se llaman directamente.

---

### CP-04 — Búsqueda de espacios disponibles con filtros
**Precondiciones:** Login como colaborador. Existen espacios tipo SALA y DESK.
**Pasos:**
1. En `Colaborador.html`, seleccionar fecha futura, hora 09:00-10:00, tipo "Sala de Juntas", capacidad mínima 4.
2. Click en "Buscar Disponibilidad".
**Resultado esperado:** Solo se listan salas (no escritorios) con capacidad ≥ 4 que estén libres en ese horario.

---

### CP-05 — Crear una reserva válida
**Precondiciones:** Espacio "Sala Innovación" (capacidad 6) libre el día de la prueba a las 15:00-16:00.
**Pasos:**
1. Buscar disponibilidad para ese horario.
2. Click en "Reservar" sobre "Sala Innovación".
3. En `Confirmacion.html`, ingresar 4 asistentes y confirmar.
**Resultado esperado:** 201 Created, mensaje de éxito, la reserva aparece en "Mis Reservas".

---

### CP-06 — Rechazo por solapamiento exacto (caso crítico del brief)
**Precondiciones:** Ya existe una reserva en "Sala Creativa" de 09:00 a 10:00 (dato seed).
**Pasos:**
1. Intentar reservar "Sala Creativa" de 09:30 a 10:30 el mismo día.
**Resultado esperado:** 409 Conflict, mensaje "El espacio ya está reservado en ese horario". La reserva NO se crea.

---

### CP-07 — Reservas consecutivas SÍ deben permitirse (límite exclusivo)
**Precondiciones:** "Sala Creativa" reservada 09:00-10:00 (seed).
**Pasos:**
1. Reservar "Sala Creativa" de 10:00 a 11:00 el mismo día.
**Resultado esperado:** 201 Created. Las reservas consecutivas (fin = inicio de la siguiente) no son solapamiento.

---

### CP-08 — Rechazo por capacidad excedida
**Precondiciones:** "Escritorio Ventana Norte" tiene capacidad 1.
**Pasos:**
1. Intentar reservar ese escritorio con `attendees = 3`.
**Resultado esperado:** 400 Bad Request, "El número de asistentes (3) excede la capacidad del espacio (1)".

---

### CP-09 — Rechazo por fecha/hora en el pasado
**Precondiciones:** Ninguna.
**Pasos:**
1. Intentar crear una reserva con `date` = ayer.
**Resultado esperado:** 400 Bad Request, "No se pueden crear reservas en una fecha/hora pasada".

---

### CP-10 — Rechazo por hora de fin menor a hora de inicio
**Precondiciones:** Ninguna.
**Pasos:**
1. `POST /api/bookings` con `start_time: "11:00"`, `end_time: "09:00"`.
**Resultado esperado:** 400 Bad Request, "La hora de fin debe ser mayor a la hora de inicio".

---

### CP-11 — Cancelar una reserva propia futura
**Precondiciones:** El colaborador tiene una reserva futura.
**Pasos:**
1. En "Mis Reservas", pestaña "Próximas", click en "Cancelar Reserva" y confirmar.
**Resultado esperado:** 200 OK, la reserva pasa a estado `CANCELLED` y desaparece de "Próximas".

---

### CP-12 — Un colaborador NO puede cancelar la reserva de otro usuario
**Precondiciones:** Reserva creada por Carlos; Ana intenta cancelarla.
**Pasos:**
1. Con el token de Ana, `DELETE /api/bookings/<id_de_reserva_de_carlos>`.
**Resultado esperado:** 403 Forbidden.

---

### CP-13 — Acceso sin token a un endpoint protegido
**Precondiciones:** Ninguna.
**Pasos:**
1. `POST /api/bookings` sin header `Authorization`.
**Resultado esperado:** 401 Unauthorized.

---

### CP-14 — CRUD de espacios como Administrador
**Precondiciones:** Login como admin.
**Pasos:**
1. Crear un espacio nuevo, editarlo (cambiar capacidad), luego eliminarlo.
**Resultado esperado:** 201 al crear, 200 al editar y reflejarse en la tabla, 200 al eliminar y desaparece del listado (soft delete).

---

### CP-15 — Filtro de disponibilidad ignorando capacidad (regresión del BUG #1 del brief)
**Precondiciones:** Existe una sala de capacidad 8 y se pide capacidad mínima 10.
**Pasos:**
1. Buscar disponibilidad con `minCapacity=10`.
**Resultado esperado:** La sala de capacidad 8 NO aparece en los resultados.
