const express = require('express');
const router = express.Router();
const { verifyToken, requireRole } = require('../middleware/auth');
const {
  getAllSpaces,
  getSpaceById,
  getAvailableSpaces,
  createSpace,
  updateSpace,
  deleteSpace
} = require('../controllers/spaceController');

/**
 * @swagger
 * components:
 *   securitySchemes:
 *     bearerAuth:
 *       type: http
 *       scheme: bearer
 *       bearerFormat: JWT
 *   schemas:
 *     Space:
 *       type: object
 *       properties:
 *         id: { type: string, format: uuid }
 *         name: { type: string, example: "Sala Creativa" }
 *         type: { type: string, enum: [SALA, DESK] }
 *         capacity: { type: integer, example: 8 }
 *         floor: { type: integer, example: 1 }
 *         description: { type: string }
 *         resources:
 *           type: array
 *           items: { type: string, enum: [PROYECTOR, PANTALLA, PIZARRA, AIRE_ACONDICIONADO, VIDEOCONFERENCIA, WIFI] }
 *     SpaceInput:
 *       type: object
 *       required: [name, type, capacity, floor]
 *       properties:
 *         name: { type: string }
 *         type: { type: string, enum: [SALA, DESK] }
 *         capacity: { type: integer }
 *         floor: { type: integer }
 *         description: { type: string }
 *         resources:
 *           type: array
 *           items: { type: string }
 */

/**
 * @swagger
 * /api/spaces:
 *   get:
 *     summary: Lista todos los espacios activos
 *     tags: [Spaces]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200:
 *         description: Lista de espacios
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items: { $ref: '#/components/schemas/Space' }
 *       401:
 *         description: Token no proporcionado o inválido
 */
router.get('/', verifyToken, getAllSpaces);

/**
 * @swagger
 * /api/spaces/available:
 *   get:
 *     summary: Busca espacios disponibles en un rango de fecha/hora
 *     tags: [Spaces]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: date
 *         required: true
 *         schema: { type: string, format: date }
 *       - in: query
 *         name: startTime
 *         required: true
 *         schema: { type: string, example: "09:00" }
 *       - in: query
 *         name: endTime
 *         required: true
 *         schema: { type: string, example: "10:00" }
 *       - in: query
 *         name: type
 *         schema: { type: string, enum: [SALA, DESK] }
 *       - in: query
 *         name: minCapacity
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Espacios disponibles en ese horario
 *       400:
 *         description: Parámetros inválidos
 *       503:
 *         description: No se pudo verificar disponibilidad (booking-service no responde)
 */
router.get('/available', verifyToken, getAvailableSpaces);

/**
 * @swagger
 * /api/spaces/{id}:
 *   get:
 *     summary: Obtiene un espacio por ID
 *     tags: [Spaces]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Espacio encontrado }
 *       404: { description: Espacio no encontrado }
 */
router.get('/:id', verifyToken, getSpaceById);

/**
 * @swagger
 * /api/spaces:
 *   post:
 *     summary: Crea un nuevo espacio (solo ADMINISTRADOR)
 *     tags: [Spaces]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/SpaceInput' }
 *     responses:
 *       201: { description: Espacio creado }
 *       400: { description: Datos inválidos }
 *       401: { description: No autenticado }
 *       403: { description: Sin permisos (no es ADMINISTRADOR) }
 */
router.post('/', verifyToken, requireRole('ADMINISTRADOR'), createSpace);

/**
 * @swagger
 * /api/spaces/{id}:
 *   put:
 *     summary: Actualiza un espacio existente (solo ADMINISTRADOR)
 *     tags: [Spaces]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/SpaceInput' }
 *     responses:
 *       200: { description: Espacio actualizado }
 *       400: { description: Datos inválidos }
 *       403: { description: Sin permisos }
 *       404: { description: Espacio no encontrado }
 */
router.put('/:id', verifyToken, requireRole('ADMINISTRADOR'), updateSpace);

/**
 * @swagger
 * /api/spaces/{id}:
 *   delete:
 *     summary: Elimina (lógicamente) un espacio (solo ADMINISTRADOR)
 *     tags: [Spaces]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Espacio eliminado }
 *       403: { description: Sin permisos }
 *       404: { description: Espacio no encontrado }
 */
router.delete('/:id', verifyToken, requireRole('ADMINISTRADOR'), deleteSpace);

module.exports = router;
