const swaggerJsdoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'OfficeSpace - Catalog Service API',
      version: '1.0.0',
      description: 'Microservicio de gestión de espacios (salas y escritorios) de Corporativo Alpha.'
    },
    servers: [{ url: 'http://localhost:3001', description: 'Servidor local' }],
    components: {
      securitySchemes: {
        bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' }
      }
    }
  },
  apis: ['./src/routes/*.js']
};

module.exports = swaggerJsdoc(options);
