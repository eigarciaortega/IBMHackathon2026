const axios = require('axios');
const { sql, getPool } = require('../db/pool');

const BOOKING_SERVICE_URL = process.env.BOOKING_SERVICE_URL || 'http://localhost:3003';

const VALID_RESOURCES = ['PROYECTOR', 'PANTALLA', 'PIZARRA', 'AIRE_ACONDICIONADO', 'VIDEOCONFERENCIA', 'WIFI'];

async function attachResources(pool, spaces) {
  if (spaces.length === 0) return spaces;

  const request = pool.request();
  const placeholders = spaces.map((s, i) => {
    request.input(`id${i}`, sql.UniqueIdentifier, s.id);
    return `@id${i}`;
  });

  const result = await request.query(
    `SELECT space_id, resource FROM space_resources WHERE space_id IN (${placeholders.join(', ')})`
  );

  const resourcesBySpace = {};
  result.recordset.forEach((r) => {
    const key = r.space_id.toUpperCase();
    if (!resourcesBySpace[key]) resourcesBySpace[key] = [];
    resourcesBySpace[key].push(r.resource);
  });

  return spaces.map((s) => ({ ...s, resources: resourcesBySpace[s.id.toUpperCase()] || [] }));
}

// GET /api/spaces
async function getAllSpaces(req, res) {
  try {
    const pool = await getPool();
    const result = await pool.request().query(
      `SELECT id, name, type, capacity, floor, description, is_active, created_at
       FROM spaces WHERE is_active = 1 ORDER BY floor, name`
    );
    const spacesWithResources = await attachResources(pool, result.recordset);
    return res.status(200).json(spacesWithResources);
  } catch (error) {
    console.error('Error al obtener espacios:', error);
    return res.status(500).json({ status: 'error', message: 'Error interno del servidor' });
  }
}

// GET /api/spaces/:id
async function getSpaceById(req, res) {
  try {
    const { id } = req.params;
    const pool = await getPool();
    const result = await pool
      .request()
      .input('id', sql.UniqueIdentifier, id)
      .query('SELECT * FROM spaces WHERE id = @id');

    if (result.recordset.length === 0) {
      return res.status(404).json({ status: 'error', message: 'Espacio no encontrado' });
    }

    const [space] = await attachResources(pool, result.recordset);
    return res.status(200).json(space);
  } catch (error) {
    console.error('Error al obtener espacio:', error);
    return res.status(500).json({ status: 'error', message: 'Error interno del servidor' });
  }
}

// GET /api/spaces/available?date=&startTime=&endTime=&type=&minCapacity=
async function getAvailableSpaces(req, res) {
  try {
    const { date, startTime, endTime, type, minCapacity } = req.query;

    if (!date || !startTime || !endTime) {
      return res.status(400).json({
        status: 'error',
        message: 'date, startTime y endTime son requeridos'
      });
    }

    if (startTime >= endTime) {
      return res.status(400).json({
        status: 'error',
        message: 'La hora de inicio debe ser menor que la hora de fin'
      });
    }

    const pool = await getPool();
    const request = pool.request();

    // 1. Filtrar espacios por tipo / capacidad mínima (BUG #1 del brief corregido aquí)
    const conditions = ['is_active = 1'];
    if (type) {
      request.input('type', sql.NVarChar, type);
      conditions.push('type = @type');
    }
    if (minCapacity) {
      request.input('minCapacity', sql.Int, parseInt(minCapacity, 10));
      conditions.push('capacity >= @minCapacity');
    }

    const candidateResult = await request.query(
      `SELECT id, name, type, capacity, floor, description FROM spaces WHERE ${conditions.join(' AND ')} ORDER BY floor, name`
    );
    const candidateSpaces = candidateResult.recordset;

    if (candidateSpaces.length === 0) {
      return res.status(200).json([]);
    }

    // 2. Preguntar al booking-service qué espacios ya están ocupados en ese rango
    //    (comunicación entre microservicios vía HTTP, no acceso directo a tablas de otro dominio)
    let busySpaceIds = [];
    try {
      const response = await axios.get(`${BOOKING_SERVICE_URL}/api/bookings/busy`, {
        params: { date, start_time: startTime, end_time: endTime }
      });
      busySpaceIds = (response.data.busySpaceIds || []).map((id) => id.toUpperCase());
    } catch (err) {
      console.error('No se pudo consultar booking-service:', err.message);
      return res.status(503).json({
        status: 'error',
        message: 'No se pudo verificar disponibilidad en este momento. Intenta de nuevo.'
      });
    }

    const availableSpaces = candidateSpaces.filter((s) => !busySpaceIds.includes(s.id.toUpperCase()));
    const withResources = await attachResources(pool, availableSpaces);

    return res.status(200).json(withResources);
  } catch (error) {
    console.error('Error al buscar disponibilidad:', error);
    return res.status(500).json({ status: 'error', message: 'Error interno del servidor' });
  }
}

function validateSpacePayload(body) {
  const errors = [];
  if (!body.name || body.name.trim().length < 3) {
    errors.push('El nombre debe tener al menos 3 caracteres');
  }
  if (!['SALA', 'DESK'].includes(body.type)) {
    errors.push('El tipo debe ser SALA o DESK');
  }
  if (!Number.isInteger(body.capacity) || body.capacity < 1) {
    errors.push('La capacidad debe ser un entero mayor a 0');
  }
  if (!Number.isInteger(body.floor) || body.floor < 1) {
    errors.push('El piso debe ser un entero mayor a 0');
  }
  if (body.resources && !Array.isArray(body.resources)) {
    errors.push('Los recursos deben ser un arreglo');
  }
  if (body.resources) {
    const invalid = body.resources.filter((r) => !VALID_RESOURCES.includes(r));
    if (invalid.length > 0) {
      errors.push(`Recursos inválidos: ${invalid.join(', ')}`);
    }
  }
  return errors;
}

async function insertResources(request, spaceId, resources) {
  if (!resources || resources.length === 0) return;
  const values = resources
    .map((_, i) => `(@spaceId, @resource${i})`)
    .join(', ');
  request.input('spaceId', sql.UniqueIdentifier, spaceId);
  resources.forEach((r, i) => request.input(`resource${i}`, sql.NVarChar, r));
  await request.query(`INSERT INTO space_resources (space_id, resource) VALUES ${values}`);
}

// POST /api/spaces (solo ADMIN)
async function createSpace(req, res) {
  const pool = await getPool();
  const transaction = new sql.Transaction(pool);
  try {
    const body = req.body;
    const errors = validateSpacePayload(body);
    if (errors.length > 0) {
      return res.status(400).json({ status: 'error', message: errors.join('. ') });
    }

    await transaction.begin();

    const insertRequest = new sql.Request(transaction);
    const insertResult = await insertRequest
      .input('name', sql.NVarChar, body.name.trim())
      .input('type', sql.NVarChar, body.type)
      .input('capacity', sql.Int, body.capacity)
      .input('floor', sql.Int, body.floor)
      .input('description', sql.NVarChar, body.description || null)
      .query(
        `INSERT INTO spaces (name, type, capacity, floor, description)
         OUTPUT INSERTED.*
         VALUES (@name, @type, @capacity, @floor, @description)`
      );

    const space = insertResult.recordset[0];

    if (body.resources && body.resources.length > 0) {
      const resRequest = new sql.Request(transaction);
      await insertResources(resRequest, space.id, body.resources);
    }

    await transaction.commit();

    const [result] = await attachResources(pool, [space]);
    return res.status(201).json(result);
  } catch (error) {
    try { await transaction.rollback(); } catch (_) { /* no-op */ }
    console.error('Error al crear espacio:', error);
    return res.status(500).json({ status: 'error', message: 'Error interno del servidor' });
  }
}

// PUT /api/spaces/:id (solo ADMIN)
async function updateSpace(req, res) {
  const pool = await getPool();
  const transaction = new sql.Transaction(pool);
  try {
    const { id } = req.params;
    const body = req.body;
    const errors = validateSpacePayload(body);
    if (errors.length > 0) {
      return res.status(400).json({ status: 'error', message: errors.join('. ') });
    }

    const existing = await pool
      .request()
      .input('id', sql.UniqueIdentifier, id)
      .query('SELECT id FROM spaces WHERE id = @id');

    if (existing.recordset.length === 0) {
      return res.status(404).json({ status: 'error', message: 'Espacio no encontrado' });
    }

    await transaction.begin();

    const updateRequest = new sql.Request(transaction);
    const updateResult = await updateRequest
      .input('id', sql.UniqueIdentifier, id)
      .input('name', sql.NVarChar, body.name.trim())
      .input('type', sql.NVarChar, body.type)
      .input('capacity', sql.Int, body.capacity)
      .input('floor', sql.Int, body.floor)
      .input('description', sql.NVarChar, body.description || null)
      .query(
        `UPDATE spaces SET name=@name, type=@type, capacity=@capacity, floor=@floor,
                description=@description, updated_at=GETDATE()
         OUTPUT INSERTED.*
         WHERE id=@id`
      );

    const deleteResRequest = new sql.Request(transaction);
    await deleteResRequest
      .input('id', sql.UniqueIdentifier, id)
      .query('DELETE FROM space_resources WHERE space_id = @id');

    if (body.resources && body.resources.length > 0) {
      const insertResRequest = new sql.Request(transaction);
      await insertResources(insertResRequest, id, body.resources);
    }

    await transaction.commit();

    const [result] = await attachResources(pool, [updateResult.recordset[0]]);
    return res.status(200).json(result);
  } catch (error) {
    try { await transaction.rollback(); } catch (_) { /* no-op */ }
    console.error('Error al actualizar espacio:', error);
    return res.status(500).json({ status: 'error', message: 'Error interno del servidor' });
  }
}

// DELETE /api/spaces/:id (solo ADMIN) - soft delete
async function deleteSpace(req, res) {
  try {
    const { id } = req.params;
    const pool = await getPool();
    const result = await pool
      .request()
      .input('id', sql.UniqueIdentifier, id)
      .query(
        `UPDATE spaces SET is_active = 0, updated_at = GETDATE() OUTPUT INSERTED.id WHERE id = @id`
      );

    if (result.recordset.length === 0) {
      return res.status(404).json({ status: 'error', message: 'Espacio no encontrado' });
    }
    return res.status(200).json({ status: 'success', message: 'Espacio eliminado correctamente' });
  } catch (error) {
    console.error('Error al eliminar espacio:', error);
    return res.status(500).json({ status: 'error', message: 'Error interno del servidor' });
  }
}

module.exports = {
  getAllSpaces,
  getSpaceById,
  getAvailableSpaces,
  createSpace,
  updateSpace,
  deleteSpace
};
