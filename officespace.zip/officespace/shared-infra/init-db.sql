-- ============================================
-- OfficeSpace - Gestión Híbrida Inteligente
-- Script de inicialización para Microsoft SQL Server 2022
--
-- NOTA: la creación de la base de datos "officespace_db" la hace
-- shared-infra/db-init/index.js ANTES de ejecutar este script (conectando
-- primero a master). Por eso este archivo ya no tiene CREATE DATABASE
-- ni USE — todo lo de aquí se ejecuta directamente contra officespace_db.
-- ============================================

-- ============================================
-- TABLA: users
-- ============================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'users')
BEGIN
    CREATE TABLE users (
        id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
        email NVARCHAR(255) NOT NULL UNIQUE,
        password_hash NVARCHAR(255) NOT NULL,
        name NVARCHAR(255) NOT NULL,
        role NVARCHAR(20) NOT NULL DEFAULT 'COLABORADOR',
        is_active BIT NOT NULL DEFAULT 1,
        created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
        updated_at DATETIME2 NOT NULL DEFAULT GETDATE(),
        CONSTRAINT chk_users_role CHECK (role IN ('ADMINISTRADOR', 'COLABORADOR'))
    );
END
GO

-- ============================================
-- TABLA: spaces
-- ============================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'spaces')
BEGIN
    CREATE TABLE spaces (
        id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
        name NVARCHAR(255) NOT NULL,
        type NVARCHAR(10) NOT NULL,
        capacity INT NOT NULL,
        floor INT NOT NULL,
        description NVARCHAR(MAX),
        is_active BIT NOT NULL DEFAULT 1,
        created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
        updated_at DATETIME2 NOT NULL DEFAULT GETDATE(),
        CONSTRAINT chk_spaces_type CHECK (type IN ('SALA', 'DESK')),
        CONSTRAINT chk_spaces_capacity CHECK (capacity > 0)
    );
END
GO

-- ============================================
-- TABLA: space_resources
-- ============================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'space_resources')
BEGIN
    CREATE TABLE space_resources (
        id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
        space_id UNIQUEIDENTIFIER NOT NULL,
        resource NVARCHAR(50) NOT NULL,
        CONSTRAINT fk_space_resources_space
            FOREIGN KEY (space_id)
            REFERENCES spaces(id)
            ON DELETE CASCADE
    );
END
GO

-- ============================================
-- TABLA: bookings
-- NOTA DE DISEÑO: start_time/end_time se guardan como VARCHAR(5) en
-- formato "HH:MM" (no TIME nativo). Es una decisión deliberada: el
-- input type="time" del frontend manda "HH:MM" y así evitamos problemas
-- de conversión/zona horaria del driver de SQL Server con el tipo TIME.
-- La comparación de horarios sigue siendo correcta porque "HH:MM" es
-- comparable lexicográficamente (mismo ancho, cero a la izquierda).
-- ============================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'bookings')
BEGIN
    CREATE TABLE bookings (
        id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
        space_id UNIQUEIDENTIFIER NOT NULL,
        user_id UNIQUEIDENTIFIER NOT NULL,
        date DATE NOT NULL,
        start_time VARCHAR(5) NOT NULL,
        end_time VARCHAR(5) NOT NULL,
        attendees INT NOT NULL,
        meeting_title NVARCHAR(255),
        notes NVARCHAR(MAX),
        status NVARCHAR(20) NOT NULL DEFAULT 'CONFIRMED',
        created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
        updated_at DATETIME2 NOT NULL DEFAULT GETDATE(),
        CONSTRAINT fk_bookings_space FOREIGN KEY (space_id) REFERENCES spaces(id) ON DELETE CASCADE,
        CONSTRAINT fk_bookings_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        CONSTRAINT chk_bookings_time_valid CHECK (end_time > start_time),
        CONSTRAINT chk_bookings_attendees_positive CHECK (attendees > 0),
        CONSTRAINT chk_bookings_status CHECK (status IN ('CONFIRMED', 'CANCELLED'))
    );

    CREATE INDEX idx_bookings_space_date ON bookings(space_id, date);
    CREATE INDEX idx_bookings_user ON bookings(user_id);
END
GO

-- ============================================
-- DATOS DE PRUEBA
-- Se siembran SOLO la primera vez (si la tabla users está vacía),
-- para que reiniciar el contenedor no truene por llaves duplicadas.
--
-- NOTA IMPORTANTE: password_hash guarda la contraseña en TEXTO PLANO
-- a propósito para este MVP de hackathon. El brief no exige
-- encriptación avanzada ("Login Simulado/Simplificado"). Para subir de
-- nivel, cambia esto por un hash (ej. bcrypt) en auth-service.
-- ============================================
IF NOT EXISTS (SELECT 1 FROM users)
BEGIN
    INSERT INTO users (id, email, password_hash, name, role) VALUES
    ('A0000000-0000-0000-0000-000000000001', 'admin@corporativoalpha.com', 'Admin123', 'Administrador Sistema', 'ADMINISTRADOR'),
    ('A0000000-0000-0000-0000-000000000002', 'carlos.mendez@corporativoalpha.com', 'User123', 'Carlos Méndez', 'COLABORADOR'),
    ('A0000000-0000-0000-0000-000000000003', 'ana.torres@corporativoalpha.com', 'User123', 'Ana Torres', 'COLABORADOR');

    INSERT INTO spaces (id, name, type, capacity, floor, description) VALUES
    ('B0000000-0000-0000-0000-000000000001', 'Sala Creativa', 'SALA', 8, 1, 'Sala moderna con proyector'),
    ('B0000000-0000-0000-0000-000000000002', 'Sala Ejecutiva', 'SALA', 12, 1, 'Sala principal para clientes'),
    ('B0000000-0000-0000-0000-000000000003', 'Sala Innovación', 'SALA', 6, 2, 'Espacio para diseño'),
    ('B0000000-0000-0000-0000-000000000101', 'Escritorio Ventana Norte', 'DESK', 1, 1, 'Escritorio individual'),
    ('B0000000-0000-0000-0000-000000000102', 'Escritorio Ventana Sur', 'DESK', 1, 1, 'Escritorio individual');

    INSERT INTO space_resources (space_id, resource) VALUES
    ('B0000000-0000-0000-0000-000000000001', 'PROYECTOR'),
    ('B0000000-0000-0000-0000-000000000001', 'PIZARRA'),
    ('B0000000-0000-0000-0000-000000000001', 'WIFI'),
    ('B0000000-0000-0000-0000-000000000002', 'PROYECTOR'),
    ('B0000000-0000-0000-0000-000000000002', 'VIDEOCONFERENCIA'),
    ('B0000000-0000-0000-0000-000000000002', 'WIFI'),
    ('B0000000-0000-0000-0000-000000000003', 'PANTALLA'),
    ('B0000000-0000-0000-0000-000000000003', 'WIFI'),
    ('B0000000-0000-0000-0000-000000000101', 'WIFI'),
    ('B0000000-0000-0000-0000-000000000102', 'WIFI');

    INSERT INTO bookings (space_id, user_id, date, start_time, end_time, attendees, meeting_title) VALUES
    ('B0000000-0000-0000-0000-000000000001', 'A0000000-0000-0000-0000-000000000002', CAST(GETDATE() AS DATE), '09:00', '10:30', 5, 'Reunión de Equipo'),
    ('B0000000-0000-0000-0000-000000000101', 'A0000000-0000-0000-0000-000000000003', CAST(GETDATE() AS DATE), '11:00', '14:00', 1, 'Trabajo concentrado');
END
GO

SELECT email, name, role FROM users;
SELECT name, type, capacity, floor FROM spaces;
GO
