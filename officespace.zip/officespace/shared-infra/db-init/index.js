const sql = require('mssql');
const fs = require('fs');

const SA_PASSWORD = process.env.SA_PASSWORD;
const DB_HOST = process.env.DB_HOST || 'mssql';
const DB_PORT = parseInt(process.env.DB_PORT || '1433', 10);
const DB_NAME = process.env.DB_NAME || 'officespace_db';
const MAX_RETRIES = 40;

const baseConfig = {
  server: DB_HOST,
  port: DB_PORT,
  user: 'sa',
  password: SA_PASSWORD,
  options: { encrypt: false, trustServerCertificate: true },
  connectionTimeout: 5000
};

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Espera a que SQL Server acepte conexiones. El contenedor mssql puede
 * tardar 20-60s en estar realmente listo aunque el proceso ya "arrancó".
 */
async function waitForServer() {
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      const pool = await new sql.ConnectionPool(baseConfig).connect();
      await pool.close();
      console.log('✅ SQL Server está listo.');
      return;
    } catch (err) {
      console.log(`⏳ Esperando a SQL Server... intento ${attempt}/${MAX_RETRIES} (${err.message})`);
      await sleep(2000);
    }
  }
  throw new Error('SQL Server no respondió después de varios intentos.');
}

/**
 * Crea la base de datos officespace_db si no existe (conectando a master,
 * la base por defecto cuando no se especifica "database" en la config).
 */
async function ensureDatabase() {
  const pool = await new sql.ConnectionPool(baseConfig).connect();
  await pool.request().batch(`
    IF DB_ID('${DB_NAME}') IS NULL
    BEGIN
      CREATE DATABASE ${DB_NAME};
    END
  `);
  await pool.close();
  console.log(`✅ Base de datos "${DB_NAME}" verificada/creada.`);
}

/**
 * Ejecuta shared-infra/init-db.sql contra officespace_db.
 * Se separa por "GO" en su propia línea (sintaxis de sqlcmd, no válida
 * para el driver mssql) y cada lote se ejecuta como un batch T-SQL.
 */
async function runInitScript() {
  const scriptPath = '/scripts/init-db.sql';
  const content = fs.readFileSync(scriptPath, 'utf8');

  const batches = content
    .split(/^\s*GO\s*$/gim)
    .map((b) => b.trim())
    .filter((b) => b.length > 0);

  const pool = await new sql.ConnectionPool({ ...baseConfig, database: DB_NAME }).connect();

  for (let i = 0; i < batches.length; i++) {
    try {
      await pool.request().batch(batches[i]);
    } catch (err) {
      console.error(`❌ Error ejecutando el lote #${i + 1} de init-db.sql:`);
      console.error(batches[i].slice(0, 300));
      await pool.close();
      throw err;
    }
  }

  await pool.close();
  console.log(`🌱 init-db.sql ejecutado correctamente (${batches.length} lotes).`);
}

(async () => {
  try {
    await waitForServer();
    await ensureDatabase();
    await runInitScript();
    console.log('🎉 Base de datos officespace_db inicializada y sembrada correctamente.');
    process.exit(0);
  } catch (err) {
    console.error('💥 Falló la inicialización de la base de datos:', err.message);
    process.exit(1);
  }
})();
