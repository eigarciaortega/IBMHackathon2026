# Arquitectura de OfficeSpace

## Diagrama de arquitectura

```mermaid
flowchart TB
    subgraph Cliente
        FE[Frontend<br/>Login / Colaborador / Confirmación / Admin<br/>:8080]
    end

    subgraph Microservicios
        AUTH[auth-service<br/>:3002<br/>Login + JWT]
        CATALOG[catalog-service<br/>:3001<br/>CRUD Espacios + Búsqueda]
        BOOKING[booking-service<br/>:3003<br/>Motor de Reservas]
    end

    DB[(SQL Server :1433<br/>officespace_db)]

    FE -->|POST /api/auth/login| AUTH
    FE -->|CRUD /api/spaces| CATALOG
    FE -->|POST/DELETE /api/bookings| BOOKING
    FE -->|GET /api/bookings/my-bookings| BOOKING

    CATALOG -->|GET /api/bookings/busy<br/>¿qué espacios están ocupados?| BOOKING
    BOOKING -->|GET /api/spaces/:id<br/>¿existe? ¿qué capacidad tiene?| CATALOG

    AUTH --- DB
    CATALOG --- DB
    BOOKING --- DB
```

## ¿Por qué microservicios con base de datos compartida?

Es la decisión que exige el brief del hackathon, y para este alcance (3 dominios:
auth, catálogo, reservas) tiene sentido práctico:

- **Menor complejidad de despliegue** en 12 horas: un solo motor de base de datos
  (SQL Server), tres procesos Node.
- **Separación real de responsabilidades**: cada servicio tiene su propio puerto, su propio
  `package.json`, su propio `Dockerfile` y se puede escalar o redesplegar de forma independiente.
- **Comunicación vía HTTP entre servicios para reglas de negocio cruzadas**:
  - `catalog-service` nunca lee la tabla `bookings` directamente. Le pregunta a
    `booking-service` (`GET /api/bookings/busy`) qué espacios están ocupados.
  - `booking-service` nunca lee la tabla `spaces` directamente para crear una reserva.
    Le pregunta a `catalog-service` (`GET /api/spaces/:id`) si el espacio existe y
    cuál es su capacidad.
- **Lecturas vs. escrituras**: la única excepción es `GET /api/bookings/my-bookings`,
  donde `booking-service` hace un `JOIN` directo con `spaces` para enriquecer la respuesta
  (nombre, tipo, piso) sin un round-trip HTTP extra. Es una decisión de lectura, no de
  lógica de negocio, y es exactamente el tipo de atajo que la arquitectura híbrida
  (microservicios + DB compartida) está pensada para permitir.

## Por qué Microsoft SQL Server (en vez de PostgreSQL)

El equipo está más cómodo con SQL Server, así que se usa `mcr.microsoft.com/mssql/server:2022-latest`
y el driver oficial `mssql` (npm) en los tres servicios. Dos decisiones derivadas de este motor:

- **`start_time` / `end_time` se guardan como `VARCHAR(5)`** ("HH:MM") en vez de `TIME` nativo.
  El driver `mssql` puede devolver columnas `TIME` envueltas en objetos `Date` con fecha base
  1970-01-01, lo que complica innecesariamente la comparación de horarios. Guardarlos como texto
  de ancho fijo ("09:00", "14:30") permite seguir comparando con `<` / `>` de forma 100% confiable
  en JavaScript, porque son strings del mismo largo con ceros a la izquierda.
- **Inicialización vía contenedor `db-init`**: a diferencia de la imagen oficial de Postgres,
  la imagen de SQL Server no ejecuta automáticamente scripts al arrancar. Por eso el
  `docker-compose.yml` incluye un servicio `db-init` (un script de Node.js con el driver
  `mssql`) que espera a que SQL Server acepte conexiones, crea la base `officespace_db` si
  no existe, y luego ejecuta `init-db.sql` por lotes (separados por `GO`). Los demás servicios
  declaran `depends_on: db-init: condition: service_completed_successfully`, así que nunca
  arrancan antes de que la base de datos exista y esté sembrada.

## Comunicación entre servicios

| Quién llama | A quién | Endpoint | Para qué |
|---|---|---|---|
| catalog-service | booking-service | `GET /api/bookings/busy` | Saber qué espacios excluir en una búsqueda de disponibilidad |
| booking-service | catalog-service | `GET /api/spaces/:id` | Validar existencia y capacidad antes de crear una reserva |

## Autenticación

- JWT firmado con un secreto compartido (`JWT_SECRET`) entre los tres servicios.
- El token incluye `sub` (user id), `email`, `role` y `name`.
- Cada servicio valida el token de forma independiente con su propio middleware
  (`verifyToken` + `requireRole`), sin llamar a `auth-service` en cada request
  (evita un punto único de fallo y latencia extra). `auth-service` expone
  `GET /api/auth/verify` para cuando alguien quiera validar manualmente.

## Por qué NO se valida contraseña con bcrypt en este MVP

El brief es explícito: *"No se requiere un sistema de login robusto con encriptación
avanzada"*. Por simplicidad y velocidad de desarrollo en el hackathon, `password_hash`
guarda la contraseña en texto plano y se compara con `===`. Está documentado como
decisión consciente, no como descuido — y es trivial de mejorar después (`bcrypt.hash`
al sembrar la BD + `bcrypt.compare` en el login).
