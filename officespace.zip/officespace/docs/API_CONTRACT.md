# Contrato de API - OfficeSpace

> Documentación interactiva completa en Swagger:
> - Auth: http://localhost:3002/api-docs
> - Catalog: http://localhost:3001/api-docs
> - Booking: http://localhost:3003/api-docs

## auth-service (puerto 3002)

### POST /api/auth/login
```bash
curl -X POST http://localhost:3002/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@corporativoalpha.com","password":"Admin123"}'
```
Respuesta 200:
```json
{ "status": "success", "token": "eyJ...", "role": "ADMINISTRADOR", "email": "admin@corporativoalpha.com", "name": "Administrador Sistema" }
```
Respuesta 401: credenciales inválidas.

---

## catalog-service (puerto 3001)

| Método | Ruta | Rol | Descripción |
|---|---|---|---|
| GET | /api/spaces | Autenticado | Lista todos los espacios activos |
| GET | /api/spaces/:id | Autenticado | Detalle de un espacio |
| GET | /api/spaces/available | Autenticado | Espacios libres en un rango fecha/hora |
| POST | /api/spaces | ADMINISTRADOR | Crea un espacio |
| PUT | /api/spaces/:id | ADMINISTRADOR | Edita un espacio |
| DELETE | /api/spaces/:id | ADMINISTRADOR | Elimina (soft delete) un espacio |

```bash
# Buscar disponibilidad
curl "http://localhost:3001/api/spaces/available?date=2026-06-25&startTime=09:00&endTime=10:00&type=SALA&minCapacity=4" \
  -H "Authorization: Bearer <token>"

# Crear espacio (admin)
curl -X POST http://localhost:3001/api/spaces \
  -H "Authorization: Bearer <token_admin>" -H "Content-Type: application/json" \
  -d '{"name":"Sala Norte","type":"SALA","capacity":6,"floor":2,"resources":["WIFI","PROYECTOR"]}'
```

---

## booking-service (puerto 3003)

| Método | Ruta | Rol | Descripción |
|---|---|---|---|
| POST | /api/bookings | Autenticado | Crea una reserva (motor de validaciones) |
| GET | /api/bookings/my-bookings | Autenticado | Reservas del usuario logueado |
| DELETE | /api/bookings/:id | Dueño o ADMIN | Cancela una reserva futura |
| GET | /api/bookings/stats?date= | ADMINISTRADOR | Conteo de reservas del día |
| GET | /api/bookings/busy?date&start_time&end_time | Interno | Usado por catalog-service |

```bash
# Crear reserva
curl -X POST http://localhost:3003/api/bookings \
  -H "Authorization: Bearer <token>" -H "Content-Type: application/json" \
  -d '{"space_id":"<uuid>","date":"2026-06-25","start_time":"09:00","end_time":"10:00","attendees":4}'
```

### Códigos de respuesta usados en todo el sistema

| Código | Significado |
|---|---|
| 200 | OK |
| 201 | Recurso creado |
| 400 | Validación fallida (datos de entrada incorrectos) |
| 401 | No autenticado / token ausente o inválido |
| 403 | Autenticado pero sin permisos para esta acción |
| 404 | Recurso no encontrado |
| 409 | Conflicto (solapamiento de horario) |
| 500 | Error interno |
| 503 | Un servicio dependiente no respondió |
