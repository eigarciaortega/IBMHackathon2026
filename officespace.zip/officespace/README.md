# 🏢 OfficeSpace — Gestión Híbrida Inteligente

MVP para **Corporativo Alpha**: reserva de salas de juntas y escritorios sin
duplicidad de reservas, con roles de Administrador y Colaborador.

## Stack

- **Backend:** Node.js + Express, arquitectura de microservicios con BD compartida
- **Base de datos:** Microsoft SQL Server 2022
- **Frontend:** HTML/CSS/JS puro (4 pantallas)
- **Auth:** JWT
- **Docs de API:** Swagger / OpenAPI
- **Orquestación:** Docker Compose

## Arquitectura

Ver [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) para el diagrama completo y las
decisiones técnicas justificadas. Resumen:

```
frontend (8080) → auth-service (3002)      → SQL Server (1433)
                → catalog-service (3001)   → SQL Server
                → booking-service (3003)   → SQL Server
catalog-service  ⇄ booking-service          (HTTP, para disponibilidad)
booking-service  ⇄ catalog-service          (HTTP, para validar espacio)
```

## 🚀 Instalación y ejecución

### Requisitos previos
- Docker y Docker Compose instalados
- Puertos libres: 1433, 3001, 3002, 3003, 8080

### Levantar todo el sistema
```bash
docker-compose up --build
```

Esto va a:
1. Levantar SQL Server 2022.
2. Ejecutar `db-init`, que crea la base de datos, las tablas y los datos de prueba
   (espera a que SQL Server esté listo antes de correr el script — puede tardar
   entre 30 y 90 segundos la primera vez).
3. Levantar `auth-service`, `catalog-service` y `booking-service`.
4. Levantar el `frontend` servido con nginx.

### Acceder a la aplicación
- **Frontend:** http://localhost:8080
- **Swagger Auth:** http://localhost:3002/api-docs
- **Swagger Catalog:** http://localhost:3001/api-docs
- **Swagger Booking:** http://localhost:3003/api-docs

### Credenciales de prueba

| Rol | Email | Password |
|---|---|---|
| Administrador | admin@corporativoalpha.com | Admin123 |
| Colaborador | carlos.mendez@corporativoalpha.com | User123 |
| Colaborador | ana.torres@corporativoalpha.com | User123 |

### Apagar todo
```bash
docker-compose down          # detiene los contenedores
docker-compose down -v       # además borra el volumen de SQL Server (reinicia datos)
```

### Ejecutar un servicio fuera de Docker (desarrollo local)
```bash
cd catalog-service
cp .env.example .env       # ajusta DB_HOST a localhost si SQL Server corre en Docker
npm install
npm run dev
```

## 📖 Guía de uso

1. **Login:** entra con cualquiera de las credenciales de prueba.
2. **Como Colaborador:**
   - Busca espacios disponibles filtrando por fecha, horario, tipo y capacidad mínima.
   - Click en "Reservar" → revisa el resumen → confirma.
   - En "Mis Reservas" puedes ver tu historial y cancelar reservas futuras.
3. **Como Administrador:**
   - Ve el dashboard de ocupación del día.
   - Crea, edita o elimina espacios desde la tabla de gestión.

## 📚 Documentación de API

Contrato completo con ejemplos de `curl` en [`docs/API_CONTRACT.md`](docs/API_CONTRACT.md).
Documentación interactiva en Swagger (links arriba).

## 🧪 Testing

| Tipo | Ubicación |
|---|---|
| Casos de prueba manuales (15) | [`testing/CASOS_DE_PRUEBA.md`](testing/CASOS_DE_PRUEBA.md) |
| Escenarios Gherkin (BDD) | [`testing/gherkin/booking-engine.feature`](testing/gherkin/booking-engine.feature) |
| Colección de Postman (con tests automáticos) | [`testing/postman/OfficeSpace.postman_collection.json`](testing/postman/OfficeSpace.postman_collection.json) |
| Reporte de bugs ("The Office Auditor") | [`testing/REPORTE_DE_BUGS.md`](testing/REPORTE_DE_BUGS.md) |
| Pruebas unitarias de la lógica crítica | `booking-service/tests/bookingValidators.test.js` |

### Correr las pruebas unitarias
```bash
cd booking-service
npm test
```
Cubren la regla más importante del reto: el algoritmo de no-solapamiento de horarios
(incluyendo el caso "abrazo", reservas consecutivas, y formatos de hora mixtos).

### Correr la colección de Postman con Newman
```bash
npm install -g newman
newman run testing/postman/OfficeSpace.postman_collection.json
```

## 🐛 Reglas de negocio críticas (resumen)

1. **No-solapamiento:** dos reservas en el mismo espacio no pueden cruzarse en el tiempo.
   Reservas consecutivas (10:00-11:00 y 11:00-12:00) SÍ están permitidas (límite exclusivo).
2. **Consistencia temporal:** `end_time` siempre debe ser mayor que `start_time`.
3. **No reservas en el pasado.**
4. **Capacidad:** los asistentes no pueden exceder la capacidad del espacio.
5. **Permisos:** solo ADMINISTRADOR gestiona espacios; solo el dueño de una reserva
   (o un ADMINISTRADOR) puede cancelarla.

## Estructura del repositorio

```
officespace/
├── auth-service/        # Microservicio de autenticación (JWT)
├── catalog-service/     # Microservicio de gestión de espacios
├── booking-service/      # Microservicio del motor de reservas (lógica crítica)
├── frontend/             # 4 pantallas: Login, Colaborador, Confirmación, Administrador
├── shared-infra/         # init-db.sql + Dockerfile del inicializador de BD
├── docs/                 # ARCHITECTURE.md, API_CONTRACT.md
├── testing/              # Casos manuales, Gherkin, Postman, reporte de bugs
└── docker-compose.yml
```

## Decisiones de diseño (para el pitch)

- **Microservicios + BD compartida:** exigido por el brief. `catalog-service` y
  `booking-service` se comunican vía HTTP para reglas cruzadas (disponibilidad,
  validación de espacio), no acceden a las tablas del otro dominio directamente.
- **SQL Server en vez de PostgreSQL:** decisión del equipo por familiaridad. Los
  horarios se guardan como `VARCHAR(5)` ("HH:MM") en vez de `TIME` nativo para
  evitar inconsistencias del driver `mssql` con tipos de hora — ver detalle en
  `docs/ARCHITECTURE.md`.
- **Passwords en texto plano:** decisión consciente, permitida explícitamente por
  el brief ("Login Simulado/Simplificado"). Documentado como mejora futura.
