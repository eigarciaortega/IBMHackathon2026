const jwt = require('jsonwebtoken');
const { sql, getPool } = require('../db/pool');

const JWT_SECRET = process.env.JWT_SECRET || 'officespace_super_secret_dev_key';
const JWT_EXPIRES_IN = '8h';

/**
 * POST /api/auth/login
 * Valida credenciales contra la tabla users y devuelve un JWT.

 */
async function login(req, res) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        status: 'error',
        message: 'Email y contraseña son requeridos'
      });
    }

    const pool = await getPool();
    const result = await pool
      .request()
      .input('email', sql.NVarChar, email.toLowerCase().trim())
      .query(
        'SELECT id, email, password_hash, name, role, is_active FROM users WHERE email = @email'
      );

    const user = result.recordset[0];

    if (!user || !user.is_active || user.password_hash !== password) {
      return res.status(401).json({
        status: 'error',
        message: 'Credenciales inválidas'
      });
    }

    const token = jwt.sign(
      {
        sub: user.id,
        email: user.email,
        role: user.role,
        name: user.name
      },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    return res.status(200).json({
      status: 'success',
      token,
      role: user.role,
      email: user.email,
      name: user.name,
      userId: user.id
    });
  } catch (error) {
    console.error('Error en login:', error);
    return res.status(500).json({ status: 'error', message: 'Error interno del servidor' });
  }
}

/**
 * GET /api/auth/verify
 * Endpoint interno usado por otros microservicios (o el frontend)
 * para validar si un token sigue siendo válido.
 */
async function verify(req, res) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ status: 'error', message: 'Token no proporcionado' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    return res.status(200).json({ status: 'success', valid: true, user: decoded });
  } catch (error) {
    return res.status(401).json({ status: 'error', valid: false, message: 'Token inválido o expirado' });
  }
}

module.exports = { login, verify };
