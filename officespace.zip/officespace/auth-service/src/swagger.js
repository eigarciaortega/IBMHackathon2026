const swaggerJsdoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'OfficeSpace - Auth Service API',
      version: '1.0.0',
      description: 'Microservicio de autenticación. Genera y valida tokens JWT para Corporativo Alpha.'
    },
    servers: [{ url: 'http://localhost:3002', description: 'Servidor local' }],
    components: {
      securitySchemes: {
        bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' }
      }
    }
  },
  apis: ['./src/routes/*.js']
};

module.exports = swaggerJsdoc(options);
