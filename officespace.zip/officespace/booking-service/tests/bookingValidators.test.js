const test = require('node:test');
const assert = require('node:assert');
const {
  isOverlapping,
  isEndAfterStart,
  isCapacityValid,
  normalizeTime
} = require('../src/validators/bookingValidators');

// ============================================
// isOverlapping - la regla más crítica del reto
// ============================================

test('NO debe solapar: reservas consecutivas (10:00-11:00 y 11:00-12:00)', () => {
  assert.strictEqual(isOverlapping('10:00:00', '11:00:00', '11:00:00', '12:00:00'), false);
});

test('SÍ debe solapar: el "abrazo" de horarios (09:00-12:00 envuelve a 10:00-11:00)', () => {
  assert.strictEqual(isOverlapping('10:00:00', '11:00:00', '09:00:00', '12:00:00'), true);
});

test('SÍ debe solapar: inicio dentro de un rango existente (09:00-10:00 y 09:30-10:30)', () => {
  assert.strictEqual(isOverlapping('09:00:00', '10:00:00', '09:30:00', '10:30:00'), true);
});

test('SÍ debe solapar: rangos idénticos', () => {
  assert.strictEqual(isOverlapping('09:00:00', '10:00:00', '09:00:00', '10:00:00'), true);
});

test('NO debe solapar: horarios completamente separados', () => {
  assert.strictEqual(isOverlapping('09:00:00', '10:00:00', '14:00:00', '15:00:00'), false);
});

// ============================================
// normalizeTime - corrige bug de formato HH:MM vs HH:MM:SS
// ============================================

test('normalizeTime agrega segundos cuando faltan', () => {
  assert.strictEqual(normalizeTime('09:00'), '09:00:00');
});

test('normalizeTime no modifica si ya tiene segundos', () => {
  assert.strictEqual(normalizeTime('09:00:00'), '09:00:00');
});

test('Reservas consecutivas con formato mixto (HH:MM vs HH:MM:SS) no deben solapar', () => {
  const existingStart = normalizeTime('10:00:00');
  const existingEnd = normalizeTime('11:00:00');
  const newStart = normalizeTime('11:00');
  const newEnd = normalizeTime('12:00');
  assert.strictEqual(isOverlapping(existingStart, existingEnd, newStart, newEnd), false);
});

// ============================================
// isEndAfterStart - consistencia temporal
// ============================================

test('Rechaza cuando end_time es menor que start_time', () => {
  assert.strictEqual(isEndAfterStart('11:00:00', '09:00:00'), false);
});

test('Acepta cuando end_time es mayor que start_time', () => {
  assert.strictEqual(isEndAfterStart('09:00:00', '10:00:00'), true);
});

test('Rechaza cuando end_time es igual a start_time', () => {
  assert.strictEqual(isEndAfterStart('09:00:00', '09:00:00'), false);
});

// ============================================
// isCapacityValid
// ============================================

test('Rechaza asistentes que exceden la capacidad del espacio', () => {
  assert.strictEqual(isCapacityValid(10, 8), false);
});

test('Acepta asistentes dentro de la capacidad', () => {
  assert.strictEqual(isCapacityValid(5, 8), true);
});

test('Rechaza 0 o negativos asistentes', () => {
  assert.strictEqual(isCapacityValid(0, 8), false);
  assert.strictEqual(isCapacityValid(-3, 8), false);
});

test('Acepta exactamente la capacidad máxima (límite inclusivo)', () => {
  assert.strictEqual(isCapacityValid(8, 8), true);
});
