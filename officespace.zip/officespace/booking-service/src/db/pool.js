const sql = require('mssql');

const config = {
  server: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '1433', 10),
  database: process.env.DB_NAME || 'officespace_db',
  user: process.env.DB_USER || 'sa',
  password: process.env.DB_PASSWORD || 'OfficeSpace2026!',
  options: {
    encrypt: false, // poner en true si se usa Azure SQL
    trustServerCertificate: true
  },
  pool: { max: 10, min: 0, idleTimeoutMillis: 30000 }
};

let poolPromise = null;

/**
 * Devuelve un ConnectionPool ya conectado, reutilizando la conexión
 * entre requests (igual que hacía `pg.Pool`).
 */
function getPool() {
  if (!poolPromise) {
    poolPromise = new sql.ConnectionPool(config).connect().catch((err) => {
      console.error('Error al conectar a SQL Server (booking-service):', err.message);
      poolPromise = null;
      throw err;
    });
  }
  return poolPromise;
}

module.exports = { sql, getPool };
