/**
 * VALIDADORES DE LA LÓGICA CRÍTICA DE RESERVAS
 * ===============================================
 * Estas funciones son deliberadamente puras (sin DB, sin red) para que
 * sean fáciles de probar con pruebas unitarias.
 *
 * Corrigen explícitamente los bugs del "Buggy Controller" del brief:
 *   BUG #2 -> isOverlapping()      (solapamiento real, no solo start===start)
 *   BUG #3 -> se resuelve en el controller devolviendo 409, no 200
 *   BUG #4 -> isEndAfterStart()
 *   BUG #5 -> isCapacityValid()
 */

/**
 * Normaliza horas a formato HH:MM (5 caracteres), que es lo que acepta la
 * columna VARCHAR(5) en SQL Server. Soporta tres casos de entrada:
 *   - Objetos Date (extrae hora y minuto)
 *   - "H:MM" (un solo dígito de hora) -> le agrega el cero ("9:00" -> "09:00")
 *   - "HH:MM:SS" -> recorta los segundos ("09:00:00" -> "09:00")
 * Evita el error de SQL Server "invalid data length" que ocurre si se
 * intenta guardar más de 5 caracteres en esa columna.
 */
function normalizeTime(time) {
  if (!time) return time;

  if (time instanceof Date) {
    const hours = time.getHours().toString().padStart(2, '0');
    const minutes = time.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  }

  const str = time.toString();
  const parts = str.split(':');
  return `${parts[0].padStart(2, '0')}:${parts[1].padStart(2, '0')}`;
}

/**
 * Regla del "Abrazo" de horarios + solapamiento general.
 * Dos rangos [start1, end1) y [start2, end2) se solapan si:
 *   start1 < end2  AND  end1 > start2
 * El límite es EXCLUSIVO: una reserva que termina a las 11:00 y otra que
 * empieza a las 11:00 NO se solapan (reservas consecutivas permitidas).
 */
function isOverlapping(start1, end1, start2, end2) {
  return start1 < end2 && end1 > start2;
}

function isEndAfterStart(startTime, endTime) {
  return endTime > startTime;
}

function isDateNotInPast(date, startTime) {
  const now = new Date();
  const bookingDateTime = new Date(`${date}T${startTime}:00`);
  return bookingDateTime >= now;
}

/**
 * Valida capacidad. Incluye Number.isInteger para rechazar valores como
 * 2.5 asistentes, que no tienen sentido en el dominio del negocio.
 */
function isCapacityValid(attendees, capacity) {
  return Number.isInteger(attendees) && attendees > 0 && attendees <= capacity;
}

module.exports = {
  normalizeTime,
  isOverlapping,
  isEndAfterStart,
  isDateNotInPast,
  isCapacityValid
};