const swaggerJsdoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'OfficeSpace - Booking Service API',
      version: '1.0.0',
      description: 'Microservicio del motor de reservas. Contiene la lógica crítica anti-solapamiento de Corporativo Alpha.'
    },
    servers: [{ url: 'http://localhost:3003', description: 'Servidor local' }],
    components: {
      securitySchemes: {
        bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' }
      }
    }
  },
  apis: ['./src/routes/*.js']
};

module.exports = swaggerJsdoc(options);
