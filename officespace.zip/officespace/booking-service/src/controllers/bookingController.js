const axios = require('axios');
const { sql, getPool } = require('../db/pool');
const {
  isOverlapping,
  isEndAfterStart,
  isDateNotInPast,
  isCapacityValid,
  normalizeTime
} = require('../validators/bookingValidators');

const CATALOG_SERVICE_URL = process.env.CATALOG_SERVICE_URL || 'http://localhost:3001';

async function fetchSpace(spaceId, authHeader) {
  const response = await axios.get(`${CATALOG_SERVICE_URL}/api/spaces/${spaceId}`, {
    headers: { Authorization: authHeader }
  });
  return response.data;
}

/**
 * POST /api/bookings
 */
async function createBooking(req, res) {
  try {
    const { space_id, date, start_time, end_time, attendees, meeting_title, notes } = req.body;

    if (!space_id || !date || !start_time || !end_time || attendees === undefined) {
      return res.status(400).json({
        status: 'error',
        message: 'space_id, date, start_time, end_time y attendees son requeridos'
      });
    }

    const startTime = normalizeTime(start_time);
    const endTime = normalizeTime(end_time);

    if (!isEndAfterStart(startTime, endTime)) {
      return res.status(400).json({
        status: 'error',
        message: 'La hora de fin debe ser mayor a la hora de inicio'
      });
    }

    if (!isDateNotInPast(date, startTime)) {
      return res.status(400).json({
        status: 'error',
        message: 'No se pueden crear reservas en una fecha/hora pasada'
      });
    }

    let space;
    try {
      space = await fetchSpace(space_id, req.headers.authorization);
    } catch (err) {
      if (err.response && err.response.status === 404) {
        return res.status(404).json({ status: 'error', message: 'El espacio no existe' });
      }
      console.error('Error al consultar catalog-service:', err.message);
      return res.status(503).json({ status: 'error', message: 'No se pudo verificar el espacio. Intenta de nuevo.' });
    }

    const attendeesInt = parseInt(attendees, 10);
    if (!isCapacityValid(attendeesInt, space.capacity)) {
      return res.status(400).json({
        status: 'error',
        message: `El número de asistentes (${attendeesInt}) excede la capacidad del espacio (${space.capacity})`
      });
    }

    const pool = await getPool();

    const existingResult = await pool
      .request()
      .input('spaceId', sql.UniqueIdentifier, space_id)
      .input('date', sql.Date, date)
      .query(
        `SELECT id, start_time, end_time FROM bookings
         WHERE space_id = @spaceId AND date = @date AND status = 'CONFIRMED'`
      );

    const conflict = existingResult.recordset.find((b) =>
      isOverlapping(normalizeTime(b.start_time), normalizeTime(b.end_time), startTime, endTime)
    );

    if (conflict) {
      return res.status(409).json({
        status: 'error',
        message: 'El espacio ya está reservado en ese horario'
      });
    }

    const insertResult = await pool
      .request()
      .input('spaceId', sql.UniqueIdentifier, space_id)
      .input('userId', sql.UniqueIdentifier, req.user.sub)
      .input('date', sql.Date, date)
      .input('startTime', sql.VarChar, startTime)
      .input('endTime', sql.VarChar, endTime)
      .input('attendees', sql.Int, attendeesInt)
      .input('meetingTitle', sql.NVarChar, meeting_title || null)
      .input('notes', sql.NVarChar, notes || null)
      .query(
        `INSERT INTO bookings (space_id, user_id, date, start_time, end_time, attendees, meeting_title, notes)
         OUTPUT INSERTED.*
         VALUES (@spaceId, @userId, @date, @startTime, @endTime, @attendees, @meetingTitle, @notes)`
      );

    return res.status(201).json({
      status: 'success',
      booking: insertResult.recordset[0],
      space_name: space.name,
      space_type: space.type
    });
  } catch (error) {
    console.error('Error al crear reserva:', error);
    return res.status(500).json({ status: 'error', message: 'Error interno del servidor' });
  }
}

/**
 * GET /api/bookings/busy
 */
async function getBusySpaces(req, res) {
  try {
    const { date, start_time, end_time } = req.query;
    if (!date || !start_time || !end_time) {
      return res.status(400).json({ status: 'error', message: 'date, start_time y end_time son requeridos' });
    }

    const pool = await getPool();
    const result = await pool
      .request()
      .input('date', sql.Date, date)
      .query(
        `SELECT DISTINCT space_id, start_time, end_time FROM bookings
         WHERE date = @date AND status = 'CONFIRMED'`
      );

    const reqStart = normalizeTime(start_time);
    const reqEnd = normalizeTime(end_time);

    const busySpaceIds = result.recordset
      .filter((b) => isOverlapping(normalizeTime(b.start_time), normalizeTime(b.end_time), reqStart, reqEnd))
      .map((b) => b.space_id);

    return res.status(200).json({ busySpaceIds });
  } catch (error) {
    console.error('Error al calcular espacios ocupados:', error);
    return res.status(500).json({ status: 'error', message: 'Error interno del servidor' });
  }
}

/**
 * GET /api/bookings/my-bookings
 */
async function getMyBookings(req, res) {
  try {
    const pool = await getPool();
    const result = await pool
      .request()
      .input('userId', sql.UniqueIdentifier, req.user.sub)
      .query(
        `SELECT b.id, b.space_id, b.date, b.start_time, b.end_time, b.attendees,
                b.meeting_title, b.notes, b.status, b.created_at,
                s.name AS space_name, s.type AS space_type, s.floor AS space_floor
         FROM bookings b
         JOIN spaces s ON s.id = b.space_id
         WHERE b.user_id = @userId
         ORDER BY b.date DESC, b.start_time DESC`
      );
    return res.status(200).json(result.recordset);
  } catch (error) {
    console.error('Error al obtener mis reservas:', error);
    return res.status(500).json({ status: 'error', message: 'Error interno del servidor' });
  }
}

/**
 * DELETE /api/bookings/:id
 */
async function cancelBooking(req, res) {
  try {
    const { id } = req.params;
    const pool = await getPool();

    const result = await pool
      .request()
      .input('id', sql.UniqueIdentifier, id)
      .query('SELECT * FROM bookings WHERE id = @id');

    if (result.recordset.length === 0) {
      return res.status(404).json({ status: 'error', message: 'Reserva no encontrada' });
    }

    const booking = result.recordset[0];

    const isOwner = booking.user_id.toLowerCase() === req.user.sub.toLowerCase();
    const isAdmin = req.user.role === 'ADMINISTRADOR';
    if (!isOwner && !isAdmin) {
      return res.status(403).json({ status: 'error', message: 'No puedes cancelar una reserva que no es tuya' });
    }

    const bookingDateStr = booking.date.toISOString().split('T')[0];
    if (!isDateNotInPast(bookingDateStr, normalizeTime(booking.start_time))) {
      return res.status(400).json({ status: 'error', message: 'No se pueden cancelar reservas pasadas' });
    }

    await pool
      .request()
      .input('id', sql.UniqueIdentifier, id)
      .query("UPDATE bookings SET status = 'CANCELLED', updated_at = GETDATE() WHERE id = @id");

    return res.status(200).json({ status: 'success', message: 'Reserva cancelada correctamente' });
  } catch (error) {
    console.error('Error al cancelar reserva:', error);
    return res.status(500).json({ status: 'error', message: 'Error interno del servidor' });
  }
}

/**
 * GET /api/bookings/stats
 */
async function getStats(req, res) {
  try {
    const date = req.query.date || new Date().toISOString().split('T')[0];
    const pool = await getPool();
    const result = await pool
      .request()
      .input('date', sql.Date, date)
      .query("SELECT COUNT(*) AS total FROM bookings WHERE date = @date AND status = 'CONFIRMED'");

    return res.status(200).json({ date, todayBookings: result.recordset[0].total });
  } catch (error) {
    console.error('Error al obtener estadísticas:', error);
    return res.status(500).json({ status: 'error', message: 'Error interno del servidor' });
  }
}

module.exports = {
  createBooking,
  getBusySpaces,
  getMyBookings,
  cancelBooking,
  getStats
};