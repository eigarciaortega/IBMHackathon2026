const express = require('express');
const router = express.Router();
const { verifyToken, requireRole } = require('../middleware/auth');
const {
  createBooking,
  getBusySpaces,
  getMyBookings,
  cancelBooking,
  getStats
} = require('../controllers/bookingController');

/**
 * @swagger
 * components:
 *   securitySchemes:
 *     bearerAuth:
 *       type: http
 *       scheme: bearer
 *       bearerFormat: JWT
 *   schemas:
 *     BookingInput:
 *       type: object
 *       required: [space_id, date, start_time, end_time, attendees]
 *       properties:
 *         space_id: { type: string, format: uuid }
 *         date: { type: string, format: date, example: "2026-06-25" }
 *         start_time: { type: string, example: "09:00" }
 *         end_time: { type: string, example: "10:00" }
 *         attendees: { type: integer, example: 4 }
 *         meeting_title: { type: string }
 *         notes: { type: string }
 *     Booking:
 *       type: object
 *       properties:
 *         id: { type: string }
 *         space_id: { type: string }
 *         date: { type: string }
 *         start_time: { type: string }
 *         end_time: { type: string }
 *         attendees: { type: integer }
 *         status: { type: string, enum: [CONFIRMED, CANCELLED] }
 */

/**
 * @swagger
 * /api/bookings:
 *   post:
 *     summary: Crea una nueva reserva (motor de validaciones críticas)
 *     tags: [Bookings]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/BookingInput' }
 *     responses:
 *       201: { description: Reserva creada }
 *       400: { description: "Validación fallida (horario inconsistente, fecha pasada o capacidad excedida)" }
 *       401: { description: No autenticado }
 *       404: { description: El espacio no existe }
 *       409: { description: "Conflicto: el espacio ya está reservado en ese horario" }
 */
router.post('/', verifyToken, createBooking);

/**
 * @swagger
 * /api/bookings/busy:
 *   get:
 *     summary: (Interno) Devuelve los IDs de espacios ocupados en un rango. Consumido por catalog-service.
 *     tags: [Bookings]
 *     parameters:
 *       - in: query
 *         name: date
 *         required: true
 *         schema: { type: string, format: date }
 *       - in: query
 *         name: start_time
 *         required: true
 *         schema: { type: string }
 *       - in: query
 *         name: end_time
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Lista de space_id ocupados }
 *       400: { description: Parámetros faltantes }
 */
router.get('/busy', getBusySpaces);

/**
 * @swagger
 * /api/bookings/my-bookings:
 *   get:
 *     summary: Lista las reservas del usuario autenticado
 *     tags: [Bookings]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Lista de reservas del usuario }
 *       401: { description: No autenticado }
 */
router.get('/my-bookings', verifyToken, getMyBookings);

/**
 * @swagger
 * /api/bookings/stats:
 *   get:
 *     summary: Estadísticas de ocupación del día (solo ADMINISTRADOR)
 *     tags: [Bookings]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: date
 *         schema: { type: string, format: date }
 *     responses:
 *       200: { description: "{ date, todayBookings }" }
 *       403: { description: Sin permisos }
 */
router.get('/stats', verifyToken, requireRole('ADMINISTRADOR'), getStats);

/**
 * @swagger
 * /api/bookings/{id}:
 *   delete:
 *     summary: Cancela una reserva futura (dueño o ADMINISTRADOR)
 *     tags: [Bookings]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: string }
 *     responses:
 *       200: { description: Reserva cancelada }
 *       400: { description: No se pueden cancelar reservas pasadas }
 *       403: { description: No es el dueño de la reserva ni ADMINISTRADOR }
 *       404: { description: Reserva no encontrada }
 */
router.delete('/:id', verifyToken, cancelBooking);

module.exports = router;
