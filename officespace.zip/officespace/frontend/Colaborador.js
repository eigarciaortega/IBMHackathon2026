// Configuración de la API
const API_URL = 'http://localhost:3001/api';
const BOOKING_API_URL = 'http://localhost:3003/api';

// Variables globales
let selectedSpace = null;
let cancelingBookingId = null;
let currentBookingsFilter = 'upcoming';

// Verificar autenticación al cargar
document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');
    const userEmail = localStorage.getItem('userEmail');

    if (!token) {
        window.location.href = 'Login.html';
        return;
    }

    if (role === 'ADMINISTRADOR') {
        alert('Esta página es solo para colaboradores');
        window.location.href = 'Administrador.html';
        return;
    }

    // Mostrar email del usuario
    document.getElementById('userEmail').textContent = userEmail || 'Colaborador';

    // Establecer fecha mínima (hoy)
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('searchDate').min = today;
    document.getElementById('searchDate').value = today;

    // Establecer hora por defecto
    document.getElementById('startTime').value = '09:00';
    document.getElementById('endTime').value = '10:00';
});

// Manejar búsqueda de espacios
async function handleSearch(event) {
    event.preventDefault();

    const date = document.getElementById('searchDate').value;
    const startTime = document.getElementById('startTime').value;
    const endTime = document.getElementById('endTime').value;
    const type = document.getElementById('spaceType').value;
    const minCapacity = document.getElementById('minCapacity').value;

    // Validaciones
    if (startTime >= endTime) {
        showToast('La hora de inicio debe ser menor que la hora de fin', 'error');
        return;
    }

    try {
        const params = new URLSearchParams({
            date: date,
            startTime: startTime,
            endTime: endTime,
            type: type,
            minCapacity: minCapacity
        });

        const response = await fetch(`${API_URL}/spaces/available?${params}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });

        if (!response.ok) {
            throw new Error('Error al buscar espacios');
        }

        const spaces = await response.json();
        displayResults(spaces, date, startTime, endTime);

    } catch (error) {
        console.error('Error:', error);
        showToast('Error al buscar espacios', 'error');
    }
}

// Mostrar resultados de búsqueda
function displayResults(spaces, date, startTime, endTime) {
    const resultsSection = document.getElementById('resultsSection');
    const spacesGrid = document.getElementById('spacesGrid');
    const noResults = document.getElementById('noResults');
    const resultsCount = document.getElementById('resultsCount');

    resultsSection.style.display = 'block';
    document.getElementById('myBookingsSection').style.display = 'none';

    if (spaces.length === 0) {
        spacesGrid.innerHTML = '';
        noResults.style.display = 'block';
        resultsCount.textContent = '0';
        return;
    }

    noResults.style.display = 'none';
    resultsCount.textContent = spaces.length;

    spacesGrid.innerHTML = spaces.map(space => `
        <div class="space-card">
            <div class="space-header">
                <h4>${space.name}</h4>
                <span class="badge ${space.type === 'SALA' ? 'badge-room' : 'badge-desk'}">
                    ${space.type === 'SALA' ? '🏛️ Sala' : '💻 Escritorio'}
                </span>
            </div>
            
            <div class="space-details">
                <div class="detail-item">
                    <span class="detail-icon">👥</span>
                    <span>Capacidad: ${space.capacity} personas</span>
                </div>
                <div class="detail-item">
                    <span class="detail-icon">📍</span>
                    <span>Piso ${space.floor}</span>
                </div>
                ${space.resources && space.resources.length > 0 ? `
                    <div class="detail-item">
                        <span class="detail-icon">🛠️</span>
                        <span>${space.resources.map(r => getResourceIcon(r)).join(' ')}</span>
                    </div>
                ` : ''}
            </div>

            <button onclick='openBookingModal(${JSON.stringify(space)}, "${date}", "${startTime}", "${endTime}")' 
                    class="btn-primary btn-reserve">
                📝 Reservar
            </button>
        </div>
    `).join('');
}

// Obtener icono de recurso
function getResourceIcon(resource) {
    const icons = {
        'PROYECTOR': '📽️',
        'PANTALLA': '🖥️',
        'PIZARRA': '📝',
        'AIRE_ACONDICIONADO': '❄️',
        'VIDEOCONFERENCIA': '📹',
        'WIFI': '📶'
    };
    return `<span title="${resource}">${icons[resource] || '📦'}</span>`;
}

// Abrir modal de reserva
function openBookingModal(space, date, startTime, endTime) {
    // Guardar datos en localStorage
    localStorage.setItem('selectedSpace', JSON.stringify(space));
    localStorage.setItem('selectedDate', date);
    localStorage.setItem('selectedStartTime', startTime);
    localStorage.setItem('selectedEndTime', endTime);

    // Redirigir a la página de confirmación
    window.location.href = 'Confirmacion.html';
}

// Cerrar modal de reserva
function closeBookingModal() {
    document.getElementById('bookingModal').style.display = 'none';
    document.getElementById('bookingForm').reset();
    selectedSpace = null;
}

// Manejar confirmación de reserva
async function handleBooking(event) {
    event.preventDefault();

    const attendees = parseInt(document.getElementById('attendees').value);
    const notes = document.getElementById('bookingNotes').value;

    // Validación de capacidad
    if (attendees > selectedSpace.capacity) {
        showToast(`La capacidad máxima es ${selectedSpace.capacity} personas`, 'error');
        return;
    }

    try {
        const bookingData = {
            space_id: selectedSpace.id,
            date: document.getElementById('searchDate').value,
            start_time: document.getElementById('startTime').value,
            end_time: document.getElementById('endTime').value,
            attendees: attendees,
            notes: notes,
            user_email: localStorage.getItem('userEmail')
        };

        const response = await fetch(`${BOOKING_API_URL}/bookings`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(bookingData)
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Error al crear reserva');
        }

        showToast('¡Reserva creada exitosamente!', 'success');
        closeBookingModal();
        
        // Mostrar mis reservas después de crear
        setTimeout(() => {
            showMyBookings();
        }, 1000);

    } catch (error) {
        showToast(error.message, 'error');
    }
}

// Mostrar mis reservas
async function showMyBookings() {
    document.getElementById('resultsSection').style.display = 'none';
    document.getElementById('myBookingsSection').style.display = 'block';

    await loadMyBookings();
}

// Ocultar mis reservas
function hideMyBookings() {
    document.getElementById('myBookingsSection').style.display = 'none';
}

// Cargar mis reservas
async function loadMyBookings() {
    try {
        const response = await fetch(`${BOOKING_API_URL}/bookings/my-bookings`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });

        if (!response.ok) {
            throw new Error('Error al cargar reservas');
        }

        const bookings = await response.json();
        filterBookings(currentBookingsFilter, bookings);

    } catch (error) {
        console.error('Error:', error);
        showToast('Error al cargar reservas', 'error');
    }
}

// Filtrar reservas (próximas/pasadas)
function filterBookings(filter, bookings = null) {
    currentBookingsFilter = filter;

    // Actualizar tabs activos
    document.getElementById('tabUpcoming').classList.toggle('active', filter === 'upcoming');
    document.getElementById('tabPast').classList.toggle('active', filter === 'past');

    if (!bookings) {
        loadMyBookings();
        return;
    }

    const now = new Date();
    const bookingsList = document.getElementById('bookingsList');
    const noBookings = document.getElementById('noBookings');

    let filteredBookings = bookings.filter(booking => {
        const bookingDate = new Date(`${booking.date}T${booking.start_time}`);
        return filter === 'upcoming' ? bookingDate >= now : bookingDate < now;
    });

    if (filteredBookings.length === 0) {
        bookingsList.innerHTML = '';
        noBookings.style.display = 'block';
        return;
    }

    noBookings.style.display = 'none';

    bookingsList.innerHTML = filteredBookings.map(booking => `
        <div class="booking-card ${filter === 'past' ? 'booking-past' : ''}">
            <div class="booking-header">
                <h4>${booking.space_name || 'Espacio'}</h4>
                <span class="badge ${booking.space_type === 'SALA' ? 'badge-room' : 'badge-desk'}">
                    ${booking.space_type === 'SALA' ? '🏛️ Sala' : '💻 Escritorio'}
                </span>
            </div>

            <div class="booking-details">
                <div class="detail-item">
                    <span class="detail-icon">📅</span>
                    <span>${formatDate(booking.date)}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-icon">🕐</span>
                    <span>${booking.start_time} - ${booking.end_time}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-icon">👥</span>
                    <span>${booking.attendees} asistentes</span>
                </div>
                ${booking.notes ? `
                    <div class="detail-item">
                        <span class="detail-icon">📝</span>
                        <span>${booking.notes}</span>
                    </div>
                ` : ''}
            </div>

            ${filter === 'upcoming' ? `
                <div class="booking-actions">
                    <button onclick="openCancelModal('${booking.id}')" class="btn-danger">
                        ❌ Cancelar Reserva
                    </button>
                </div>
            ` : ''}
        </div>
    `).join('');
}

// Abrir modal de cancelación
function openCancelModal(bookingId) {
    cancelingBookingId = bookingId;
    document.getElementById('cancelModal').style.display = 'flex';
}

// Cerrar modal de cancelación
function closeCancelModal() {
    document.getElementById('cancelModal').style.display = 'none';
    cancelingBookingId = null;
}

// Confirmar cancelación
async function confirmCancel() {
    try {
        const response = await fetch(`${BOOKING_API_URL}/bookings/${cancelingBookingId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });

        if (!response.ok) {
            throw new Error('Error al cancelar reserva');
        }

        showToast('Reserva cancelada', 'success');
        closeCancelModal();
        loadMyBookings();

    } catch (error) {
        showToast(error.message, 'error');
        closeCancelModal();
    }
}

// Formatear fecha
function formatDate(dateString) {
    const date = new Date(dateString + 'T00:00:00');
    return date.toLocaleDateString('es-ES', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
}

// Mostrar notificación toast
function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast toast-${type}`;
    toast.style.display = 'block';

    setTimeout(() => {
        toast.style.display = 'none';
    }, 3000);
}

// Cerrar sesión
function logout() {
    localStorage.clear();
    window.location.href = 'Login.html';
}

// Cerrar modales al hacer clic fuera
window.onclick = function(event) {
    const bookingModal = document.getElementById('bookingModal');
    const cancelModal = document.getElementById('cancelModal');
    
    if (event.target === bookingModal) {
        closeBookingModal();
    }
    if (event.target === cancelModal) {
        closeCancelModal();
    }
}