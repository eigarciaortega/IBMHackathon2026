// Configuración de la API
const AUTH_API_URL = 'http://localhost:3002/api';

// Verificar si ya hay sesión activa
document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');

    if (token && role) {
        // Ya hay sesión activa, redirigir según rol
        redirectToRole(role);
    }
});

// Manejar login
async function handleLogin(event) {
    event.preventDefault();

    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const loginBtn = document.getElementById('loginBtn');
    const btnText = loginBtn.querySelector('.btn-text');
    const btnLoader = loginBtn.querySelector('.btn-loader');
    const errorMessage = document.getElementById('errorMessage');

    // Ocultar mensaje de error previo
    errorMessage.style.display = 'none';

    // Mostrar loader
    loginBtn.disabled = true;
    btnText.style.display = 'none';
    btnLoader.style.display = 'inline';

    try {
        const response = await fetch(`${AUTH_API_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Credenciales inválidas');
        }

        const data = await response.json();

        // Guardar en localStorage
        localStorage.setItem('token', data.token);
        localStorage.setItem('role', data.role);
        localStorage.setItem('userEmail', data.email || email);
        localStorage.setItem('userName', data.name || email.split('@')[0]);

        // Mostrar mensaje de éxito
        showSuccessMessage();

        // Redirigir después de 1 segundo
        setTimeout(() => {
            redirectToRole(data.role);
        }, 1000);

    } catch (error) {
        console.error('Error de login:', error);
        showErrorMessage(error.message || 'Error al iniciar sesión. Intenta nuevamente.');
        
        // Resetear botón
        loginBtn.disabled = false;
        btnText.style.display = 'inline';
        btnLoader.style.display = 'none';
    }
}

// Redirigir según rol
function redirectToRole(role) {
    if (role === 'ADMINISTRADOR') {
        window.location.href = 'Administrador.html';
    } else if (role === 'COLABORADOR') {
        window.location.href = 'Colaborador.html';
    } else {
        showErrorMessage('Rol no reconocido. Contacta al administrador.');
    }
}

// Mostrar mensaje de error
function showErrorMessage(message) {
    const errorMessage = document.getElementById('errorMessage');
    const errorText = document.getElementById('errorText');
    
    errorText.textContent = message;
    errorMessage.style.display = 'flex';
    errorMessage.classList.add('shake');

    setTimeout(() => {
        errorMessage.classList.remove('shake');
    }, 500);
}

// Mostrar mensaje de éxito
function showSuccessMessage() {
    const loginBtn = document.getElementById('loginBtn');
    const btnText = loginBtn.querySelector('.btn-text');
    const btnLoader = loginBtn.querySelector('.btn-loader');
    
    btnLoader.style.display = 'none';
    btnText.textContent = '✅ ¡Bienvenido!';
    btnText.style.display = 'inline';
    loginBtn.style.background = '#28a745';
}

// Permitir login con Enter
document.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        const form = document.getElementById('loginForm');
        form.requestSubmit();
    }
});