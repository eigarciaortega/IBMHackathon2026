// Configuración de la API
const BOOKING_API_URL = 'http://localhost:3003/api';

// Variables globales
let bookingData = null;

// ============================================
// INICIALIZACIÓN
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    verificarAutenticacion();
    cargarDatosReserva();
});

function verificarAutenticacion() {
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');
    const userEmail = localStorage.getItem('userEmail');

    if (!token) {
        window.location.href = 'Login.html';
        return;
    }

    if (role === 'ADMINISTRADOR') {
        alert('Los administradores no pueden hacer reservas');
        window.location.href = 'Administrador.html';
        return;
    }

    document.getElementById('userEmail').textContent = userEmail || 'Colaborador';
}

function cargarDatosReserva() {
    // Obtener datos de localStorage (guardados desde Colaborador.html)
    const spaceData = localStorage.getItem('selectedSpace');
    const dateData = localStorage.getItem('selectedDate');
    const startTimeData = localStorage.getItem('selectedStartTime');
    const endTimeData = localStorage.getItem('selectedEndTime');

    if (!spaceData || !dateData || !startTimeData || !endTimeData) {
        alert('No hay datos de reserva. Por favor, busca un espacio primero.');
        window.location.href = 'Colaborador.html';
        return;
    }

    try {
        bookingData = {
            space: JSON.parse(spaceData),
            date: dateData,
            startTime: startTimeData,
            endTime: endTimeData
        };

        // Llenar resumen
        llenarResumen();

        // Configurar input de asistentes
        const attendeesInput = document.getElementById('attendees');
        attendeesInput.max = bookingData.space.capacity;
        attendeesInput.value = 1;
        document.getElementById('capacityHint').textContent = 
            `Máximo: ${bookingData.space.capacity} personas`;

    } catch (error) {
        console.error('Error al cargar datos:', error);
        alert('Error al cargar datos de la reserva');
        window.location.href = 'Colaborador.html';
    }
}

// ============================================
// LLENAR RESUMEN
// ============================================
function llenarResumen() {
    const space = bookingData.space;

    document.getElementById('summarySpace').textContent = space.name;
    document.getElementById('summaryType').textContent = 
        space.type === 'SALA' ? 'Sala de Juntas' : 'Escritorio';
    document.getElementById('summaryDate').textContent = formatDate(bookingData.date);
    document.getElementById('summaryTime').textContent = 
        `${bookingData.startTime} - ${bookingData.endTime}`;
    document.getElementById('summaryCapacity').textContent = 
        `${space.capacity} personas`;
    document.getElementById('summaryFloor').textContent = 
        `Piso ${space.floor}`;

    // Mostrar recursos si existen
    if (space.resources && space.resources.length > 0) {
        const resourcesSection = document.getElementById('resourcesSection');
        const resourcesList = document.getElementById('resourcesList');
        
        resourcesList.innerHTML = space.resources.map(r => `
            <span class="resource-tag">
                ${getResourceIcon(r)} ${getResourceName(r)}
            </span>
        `).join('');
        
        resourcesSection.style.display = 'block';
    }
}

function getResourceIcon(resource) {
    const icons = {
        'PROYECTOR': '📽️',
        'PANTALLA': '🖥️',
        'PIZARRA': '📝',
        'AIRE_ACONDICIONADO': '❄️',
        'VIDEOCONFERENCIA': '📹',
        'WIFI': '📶'
    };
    return icons[resource] || '📦';
}

function getResourceName(resource) {
    const names = {
        'PROYECTOR': 'Proyector',
        'PANTALLA': 'Pantalla',
        'PIZARRA': 'Pizarra',
        'AIRE_ACONDICIONADO': 'Aire Acondicionado',
        'VIDEOCONFERENCIA': 'Videoconferencia',
        'WIFI': 'WiFi'
    };
    return names[resource] || resource;
}

function formatDate(dateString) {
    const date = new Date(dateString + 'T00:00:00');
    return date.toLocaleDateString('es-ES', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
}

// ============================================
// CONFIRMAR RESERVA
// ============================================
async function handleConfirmBooking(event) {
    event.preventDefault();

    const attendees = parseInt(document.getElementById('attendees').value);
    const meetingTitle = document.getElementById('meetingTitle').value.trim();
    const notes = document.getElementById('bookingNotes').value.trim();
    const confirmBtn = document.getElementById('confirmBtn');
    const btnText = confirmBtn.querySelector('.btn-text');
    const btnLoader = confirmBtn.querySelector('.btn-loader');
    const errorMessage = document.getElementById('errorMessage');

    // Ocultar mensaje de error
    errorMessage.style.display = 'none';

    // Validaciones
    if (attendees > bookingData.space.capacity) {
        showErrorMessage(`La capacidad máxima es ${bookingData.space.capacity} personas`);
        return;
    }

    if (attendees < 1) {
        showErrorMessage('Debe haber al menos 1 asistente');
        return;
    }

    // Mostrar loader
    confirmBtn.disabled = true;
    btnText.style.display = 'none';
    btnLoader.style.display = 'inline';

    try {
        const payload = {
            space_id: bookingData.space.id,
            date: bookingData.date,
            start_time: bookingData.startTime,
            end_time: bookingData.endTime,
            attendees: attendees,
            meeting_title: meetingTitle,
            notes: notes,
            user_email: localStorage.getItem('userEmail')
        };

        const response = await fetch(`${BOOKING_API_URL}/bookings`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Error al crear la reserva');
        }

        const result = await response.json();

        // Limpiar localStorage de selección
        localStorage.removeItem('selectedSpace');
        localStorage.removeItem('selectedDate');
        localStorage.removeItem('selectedStartTime');
        localStorage.removeItem('selectedEndTime');

        // Mostrar mensaje de éxito
        showSuccessMessage();

    } catch (error) {
        console.error('Error:', error);
        showErrorMessage(error.message);
        
        // Resetear botón
        confirmBtn.disabled = false;
        btnText.style.display = 'inline';
        btnLoader.style.display = 'none';
    }
}

// ============================================
// MENSAJES
// ============================================
function showErrorMessage(message) {
    const errorMessage = document.getElementById('errorMessage');
    const errorText = document.getElementById('errorText');
    
    errorText.textContent = message;
    errorMessage.style.display = 'flex';
    errorMessage.classList.add('shake');

    setTimeout(() => {
        errorMessage.classList.remove('shake');
    }, 500);
}

function showSuccessMessage() {
    // Ocultar formulario y resumen
    document.querySelector('.summary-card').style.display = 'none';
    document.querySelector('.form-card').style.display = 'none';
    
    // Mostrar mensaje de éxito
    document.getElementById('successMessage').style.display = 'block';
}

// ============================================
// NAVEGACIÓN
// ============================================
function goBack() {
    window.location.href = 'Colaborador.html';
}

function viewMyBookings() {
    window.location.href = 'Colaborador.html';
}

function makeAnotherBooking() {
    window.location.href = 'Colaborador.html';
}