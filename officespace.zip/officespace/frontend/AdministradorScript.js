// Configuración de la API
const API_URL = 'http://localhost:3001/api';
const BOOKING_API_URL = 'http://localhost:3003/api';

// Variables globales
let editingSpaceId = null;
let deletingSpaceId = null;
let allSpaces = []; // Para filtrar en el cliente

// ============================================
// INICIALIZACIÓN
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    verificarAutenticacion();
    cargarDatosIniciales();
});

function verificarAutenticacion() {
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');
    const userEmail = localStorage.getItem('userEmail');

    if (!token) {
        window.location.href = 'Login.html';
        return;
    }

    if (role !== 'ADMINISTRADOR') {
        alert('⚠️ No tienes permisos para acceder a esta página');
        window.location.href = 'Colaborador.html';
        return;
    }

    document.getElementById('userEmail').textContent = userEmail || 'Administrador';
}

async function cargarDatosIniciales() {
    await loadSpaces();
    await loadStatistics();
}

// ============================================
// CARGAR ESPACIOS
// ============================================
async function loadSpaces() {
    try {
        const response = await fetch(`${API_URL}/spaces`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`,
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            if (response.status === 401) {
                showToast('Sesión expirada. Inicia sesión nuevamente', 'error');
                setTimeout(() => window.location.href = 'Login.html', 2000);
                return;
            }
            throw new Error('Error al cargar espacios');
        }

        allSpaces = await response.json();
        renderSpacesTable(allSpaces);
        updateStatistics(allSpaces);

    } catch (error) {
        console.error('Error:', error);
        showToast('Error al cargar espacios: ' + error.message, 'error');
    }
}

// ============================================
// RENDERIZAR TABLA
// ============================================
function renderSpacesTable(spaces) {
    const tbody = document.getElementById('spacesTableBody');
    const noDataMsg = document.getElementById('noSpacesMessage');
    const table = document.getElementById('spacesTable');

    if (spaces.length === 0) {
        tbody.innerHTML = '';
        noDataMsg.style.display = 'block';
        table.style.display = 'none';
        return;
    }

    noDataMsg.style.display = 'none';
    table.style.display = 'table';

    tbody.innerHTML = spaces.map(space => `
        <tr>
            <td><strong>#${space.id}</strong></td>
            <td><strong>${space.name}</strong></td>
            <td>
                <span class="badge ${space.type === 'SALA' ? 'badge-room' : 'badge-desk'}">
                    ${space.type === 'SALA' ? '🏛️ Sala' : '💻 Escritorio'}
                </span>
            </td>
            <td>${space.capacity} personas</td>
            <td>Piso ${space.floor}</td>
            <td>
                ${space.resources && space.resources.length > 0 
                    ? space.resources.map(r => getResourceIcon(r)).join(' ')
                    : '<span class="text-muted">-</span>'}
            </td>
            <td class="actions-cell">
                <button onclick="editSpace('${space.id}')" class="btn-edit" title="Editar">
                    ✏️ Editar
                </button>
                <button onclick="deleteSpace('${space.id}')" class="btn-delete" title="Eliminar">
                    🗑️ Eliminar
                </button>
            </td>
        </tr>
    `).join('');
}

function getResourceIcon(resource) {
    const icons = {
        'PROYECTOR': '📽️',
        'PANTALLA': '🖥️',
        'PIZARRA': '📝',
        'AIRE_ACONDICIONADO': '❄️',
        'VIDEOCONFERENCIA': '📹',
        'WIFI': '📶'
    };
    return `<span class="resource-icon" title="${resource}">${icons[resource] || '📦'}</span>`;
}

// ============================================
// ESTADÍSTICAS
// ============================================
function updateStatistics(spaces) {
    const rooms = spaces.filter(s => s.type === 'SALA').length;
    const desks = spaces.filter(s => s.type === 'DESK').length;

    document.getElementById('totalSpaces').textContent = spaces.length;
    document.getElementById('totalRooms').textContent = rooms;
    document.getElementById('totalDesks').textContent = desks;
}

async function loadStatistics() {
    try {
        const today = new Date().toISOString().split('T')[0];
        const response = await fetch(`${BOOKING_API_URL}/bookings/stats?date=${today}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });

        if (response.ok) {
            const stats = await response.json();
            document.getElementById('totalBookings').textContent = stats.todayBookings || 0;
        } else {
            document.getElementById('totalBookings').textContent = '0';
        }
    } catch (error) {
        console.log('Stats no disponibles aún');
        document.getElementById('totalBookings').textContent = '0';
    }
}

// ============================================
// FILTRAR TABLA
// ============================================
function filterTable() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    
    const filtered = allSpaces.filter(space => 
        space.name.toLowerCase().includes(searchTerm) ||
        space.type.toLowerCase().includes(searchTerm)
    );
    
    renderSpacesTable(filtered);
}

// ============================================
// MODAL: CREAR / EDITAR
// ============================================
function openModal() {
    editingSpaceId = null;
    document.getElementById('modalTitle').textContent = '➕ Nuevo Espacio';
    document.getElementById('spaceForm').reset();
    document.getElementById('spaceCapacity').value = 1;
    document.getElementById('spaceFloor').value = 1;
    document.getElementById('spaceModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('spaceModal').style.display = 'none';
    editingSpaceId = null;
}

async function editSpace(id) {
    try {
        const response = await fetch(`${API_URL}/spaces/${id}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });

        if (!response.ok) throw new Error('Error al cargar espacio');

        const space = await response.json();
        editingSpaceId = id;

        document.getElementById('modalTitle').textContent = '✏️ Editar Espacio';
        document.getElementById('spaceName').value = space.name;
        document.getElementById('spaceType').value = space.type;
        document.getElementById('spaceCapacity').value = space.capacity;
        document.getElementById('spaceFloor').value = space.floor;
        document.getElementById('spaceDescription').value = space.description || '';

        // Marcar recursos
        const checkboxes = document.querySelectorAll('input[name="resources"]');
        checkboxes.forEach(cb => {
            cb.checked = space.resources && space.resources.includes(cb.value);
        });

        document.getElementById('spaceModal').style.display = 'flex';

    } catch (error) {
        showToast('Error al cargar espacio: ' + error.message, 'error');
    }
}

async function handleSubmit(event) {
    event.preventDefault();

    const formData = {
        name: document.getElementById('spaceName').value.trim(),
        type: document.getElementById('spaceType').value,
        capacity: parseInt(document.getElementById('spaceCapacity').value),
        floor: parseInt(document.getElementById('spaceFloor').value),
        description: document.getElementById('spaceDescription').value.trim(),
        resources: Array.from(document.querySelectorAll('input[name="resources"]:checked'))
            .map(cb => cb.value)
    };

    // Validaciones
    if (formData.name.length < 3) {
        showToast('El nombre debe tener al menos 3 caracteres', 'error');
        return;
    }

    if (formData.capacity < 1) {
        showToast('La capacidad debe ser al menos 1', 'error');
        return;
    }

    try {
        let url = `${API_URL}/spaces`;
        let method = 'POST';

        if (editingSpaceId) {
            url = `${API_URL}/spaces/${editingSpaceId}`;
            method = 'PUT';
        }

        const response = await fetch(url, {
            method: method,
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Error al guardar');
        }

        showToast(
            editingSpaceId ? '✅ Espacio actualizado correctamente' : '✅ Espacio creado correctamente', 
            'success'
        );
        closeModal();
        loadSpaces();

    } catch (error) {
        showToast('❌ Error: ' + error.message, 'error');
    }
}

// ============================================
// ELIMINAR ESPACIO
// ============================================
function deleteSpace(id) {
    deletingSpaceId = id;
    document.getElementById('deleteModal').style.display = 'flex';
}

function closeDeleteModal() {
    document.getElementById('deleteModal').style.display = 'none';
    deletingSpaceId = null;
}

async function confirmDelete() {
    try {
        const response = await fetch(`${API_URL}/spaces/${deletingSpaceId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Error al eliminar');
        }

        showToast('✅ Espacio eliminado correctamente', 'success');
        closeDeleteModal();
        loadSpaces();

    } catch (error) {
        showToast('❌ Error: ' + error.message, 'error');
        closeDeleteModal();
    }
}

// ============================================
// UTILIDADES
// ============================================
function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast toast-${type} show`;

    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function logout() {
    if (confirm('¿Estás seguro de que deseas cerrar sesión?')) {
        localStorage.clear();
        window.location.href = 'Login.html';
    }
}

// Cerrar modales al hacer clic fuera
window.onclick = function(event) {
    const spaceModal = document.getElementById('spaceModal');
    const deleteModal = document.getElementById('deleteModal');
    
    if (event.target === spaceModal) {
        closeModal();
    }
    if (event.target === deleteModal) {
        closeDeleteModal();
    }
}

// Cerrar modales con tecla Escape
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeModal();
        closeDeleteModal();
    }
});